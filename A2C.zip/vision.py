import os
import numpy as np
import cv2
import math
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
after_flash_image='/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/image'
after_flash_binary='/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/binary'
video_path='/data/stu1/liuanqi/heart_2C/heart_myunet/video /病例五.avi'
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print("Error opening video stream or file")
fps = cap.get(cv2.CAP_PROP_FPS)  # 获取视频的FPS（帧率）
print(fps)

#图像左上角为原点

def clean(serie):
    output = serie[(np.isnan(serie) == False) & (np.isinf(serie) == False)]
    return output

def calculate_intensity(image, points):
    """Calculate the average intensity for the given points in the image."""
    sensity=[]
    for point in points:
        sensity.append(image[point])
    return np.mean(sensity)
def main(tac_list):
    first_intensity=tac_list[0]
    first_intensity_db=np.abs(10*np.log10(first_intensity))
    tac_list_=np.array(tac_list)
    mean_intensity=np.mean(tac_list_)
    mean_intensity_db=np.abs(10*np.log10(mean_intensity))
    tac_list_db=(10*np.log10(np.maximum(tac_list_,1e-7)/first_intensity))+first_intensity_db
    tac_list_db=tac_list_db.tolist()

    return tac_list_db,mean_intensity_db

def exponential_func(t, a, b,x0,y0):
    return a * ((1 - np.exp(-b * t))-(1 - np.exp(-b * x0)))+y0

def carve(tac_list_db_,first,):
    tac_list_db_=np.array(tac_list_db_)
    clean(tac_list_db_)
        # 生成时间轴（假设时间间隔为1）
    time_axis = np.arange(len(tac_list_db_))/fps
    t = np.linspace(0, time_axis[-1], 1000)
    x0=0.1
    
    y0=min(tac_list_db_)
    tac_list_db_ = np.array(tac_list_db_)
    
    # 初始猜测参数 [a, b, c]
    initial_guess = [2, 1]
    smoothed_data = np.convolve(tac_list_db_, np.ones(5)/5, mode='valid')    # 曲线拟合
    params, params_covariance = curve_fit(lambda t,a,b:exponential_func(t,a,b,x0,y0), time_axis, tac_list_db_, p0=initial_guess, maxfev=4000)
    # 拟合结果
    fitted_signal = exponential_func(time_axis, *params,x0,y0)

    # 拟合参数
    A = params[0]
    β = params[1]
    return A,β
i=0
intensity_region_1=[]
intensity_region_2=[]
intensity_region_3=[]
intensity__region_1=[]
intensity__region_2=[]
intensity__region_3=[]
intensity_three_region=[]
for test_image in os.listdir(after_flash_image):
    points=[]
    label_image=test_image.replace('.jpg','.png')

    # 读取二值图像和原始灰度图像
    bin_img = cv2.imread(os.path.join(after_flash_binary, label_image),cv2.IMREAD_GRAYSCALE)
    gray_img = cv2.imread(os.path.join(after_flash_image, test_image),cv2.IMREAD_GRAYSCALE)
    
    if bin_img is None or gray_img is None:
        print(f"无法读取 {test_image}，请检查文件路径和格式")
        continue
    
    # 获取二值图像中白色的点的坐标
    _,bin_img=cv2.threshold(bin_img,127,255,cv2.THRESH_BINARY)
    points = np.argwhere(bin_img != 0)

    # 找到y坐标最小的点（A点）
    A_point=points[np.argmin(points[:,0])]
    print(A_point)
    # 找到与A点x坐标相同但y坐标不同的点（B点）
    B_points = points[(points[:,1] == A_point[1]) & (points[:, 0] != A_point[0])]
    if B_points.size > 0:
        B_point = B_points[np.argmax(B_points[:,0])]  # 选择y坐标最大的B点
    # 找出心尖区域
    three_region = []
    _points = []
    for point in points:
        if point[0] <= B_point[0] and point[0] >= A_point[0]:
            three_region.append(point)
        elif point[0]>B_point[0]:
            _points.append(point)
    # 找中间点作为分左右两段的基点
    xmin_point = points[np.argmin(points[:,1])]
    xmax_point = points[np.argmax(points[:,1])]
    xmid_point = (xmin_point + xmax_point) // 2
    xmid_point=A_point
    if i==0:
        print(xmax_point)
        print(xmin_point)
    right_points = []
    left_points = []
    for point in _points:
        if point[1] > xmid_point[1]:
            right_points.append(point)
        elif point[1]<=xmid_point[1]:
            left_points.append(point)
    right_points=np.array(right_points)
    left_points=np.array(left_points)
    # 找出右边y坐标最低，从而通过高度划分
    if right_points.size>1:
        ylow_point = right_points[np.argmax(right_points[:,0])]
    else:
        i+=1
        continue
    if left_points.size>1:
        _ylow_point = left_points[np.argmax(left_points[:,0])]
    else:
        i+=1
        continue
    second_ = (ylow_point[0] - B_point[0]) / 3 + B_point[0]
    first_ = 2 * (ylow_point[0] - B_point[0]) / 3 + B_point[0]
    region_1 = []
    region_2 = []
    region_3 = []
    for point in right_points:
        if point[0] > first_ and point[0] <= ylow_point[0]:
            region_1.append(point)
        elif point[0] > second_ and point[0] <= first_:
            region_2.append(point)
        else:
            region_3.append(point)
    # 找出左边y坐标最低，通过高度划分
    _second_ = (_ylow_point[0] - B_point[0]) / 3 + B_point[0]
    _first_ = 2 * (_ylow_point[0] - B_point[0]) / 3 + B_point[0]
    _region_1 = []
    _region_2 = []
    _region_3 = []
    for point in left_points:
        if point[0] > _first_ and point[0] <= _ylow_point[0]:
            _region_1.append(point)
        elif point[0] > _second_ and point[0] <= _first_:
            _region_2.append(point)
        else:
            _region_3.append(point)

    # 计算各区域的信号强度
    intensity_three_region.append(calculate_intensity(gray_img, three_region))
    intensity_region_1.append(calculate_intensity(gray_img, region_1))
    intensity_region_2.append(calculate_intensity(gray_img, region_2))
    intensity_region_3.append(calculate_intensity(gray_img, region_3))
    intensity__region_1.append(calculate_intensity(gray_img, _region_1))
    intensity__region_2.append(calculate_intensity(gray_img, _region_2))
    intensity__region_3.append(calculate_intensity(gray_img, _region_3))

    i += 1
intensity_three_region=np.array(intensity_three_region)
intensity_region_1=np.array(intensity_region_1)
intensity_region_2=np.array(intensity_region_2)
intensity_region_3=np.array(intensity_region_3)
intensity__region_1=np.array(intensity__region_1)
intensity__region_2=np.array(intensity__region_2)
intensity__region_3=np.array(intensity__region_3)

tac_list_db_1,first_1=main(clean(intensity_region_1))
tac_list_db_2,first_2=main(clean(intensity_region_2))
tac_list_db_3,first_3=main(clean(intensity_region_3))
tac_list_db_4,first_4=main(clean(intensity_three_region))
tac_list_db_5,first_5=main(clean(intensity__region_1))
tac_list_db_6,first_6=main(clean(intensity__region_2))
tac_list_db_7,first_7=main(clean(intensity__region_3))
_2_1_A,_2_1_β=carve(tac_list_db_1,first_1)
_2_2_A,_2_2_β=carve(tac_list_db_2,first_2)
_2_3_A,_2_3_β=carve(tac_list_db_3,first_3)
_2_4_A,_2_4_β=carve(tac_list_db_4,first_4)
_2_5_A,_2_5_β=carve(tac_list_db_5,first_5)
_2_6_A,_2_6_β=carve(tac_list_db_6,first_6)
_2_7_A,_2_7_β=carve(tac_list_db_7,first_7)
_2_1=_2_1_A*_2_1_β
_2_2=_2_2_A*_2_2_β
_2_3=_2_3_A*_2_3_β
_2_4=_2_4_A*_2_4_β
_2_5=_2_5_A*_2_5_β
_2_6=_2_6_A*_2_6_β
_2_7=_2_7_A*_2_7_β
_2_4_1=4.651120102873541*7.064215526479061
_2_4_2=2.879968369629264*4.680324317978228
_2_4_3=2.7784371826494954*5.614140417949923
_2_4_4=3.0807047153620704*6.968831477510587
_2_4_5=2.602348603572845*7.714069451743837
_2_4_6=2.8029256066717334*7.495825134367784
_2_4_7=2.998362492437356*7.698912656612449
_2_4_8=2.7432949287979262*8.032804964918022
_2_4_9=3.334903955143685*7.861000423808947
_2_4_10=3.2669731457225812*8.312660527755506