import cv2
import os
import shutil
import numpy as np
from PIL import Image
import matplotlib.image as mpimg

from net2 import *
from utils import *
from data import *
from torchvision.transforms.functional import to_pil_image
from torchvision.utils import save_image
from config import video_path,video_to_picture,to_picture_mask,to_picture_mask_cover

def clear_folder(folder_path):
    """
    清除指定文件夹中的所有文件。
    """
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)  # 删除文件或符号链接
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)  # 删除文件夹及其内容
        except Exception as e:
            print(f"Failed to delete {file_path}. Reason: {e}")

clear_folder(video_to_picture)
clear_folder(to_picture_mask)
clear_folder(to_picture_mask_cover)

def makevideo(videoinpath):
    i=0
    picture_path=video_to_picture
    clear_folder(picture_path)
    capture     = cv2.VideoCapture(videoinpath)
    fourcc      = cv2.VideoWriter_fourcc(*'XVID')
    if capture.isOpened():
        fps = capture.get(cv2.CAP_PROP_FPS)  # 获取视频的FPS（帧率）
        print(fps)
        frames = capture.get(cv2.CAP_PROP_FRAME_COUNT)
        print(frames)
        while True:
            ret,img_src=capture.read()
            if not ret:break
            cv2.imwrite(f'{picture_path}/{i}.jpg',img_src)
            # img_src=keep_image_size_open(f'{picture_path}/{i}.jpg')
            # img_data=transform(img_src).cuda()
            # img_data=torch.unsqueeze(img_data,dim=0)

            # img_end=img_src.convert('RGBA')
            # net.eval()
            # with torch.no_grad():
            #     img_out=net(img_data)
            # out = img_out.squeeze()
            # out_pil=to_pil_image(out)
            # out_end=out_pil.convert('RGBA')

            # image_end=Image.blend(img_end,out_end,0.4)
            # image_end.save(f'{picture_path_out}/{i}.png')
            # img_data=transform(img_src).cuda()
            # img_data=torch.unsqueeze(img_data,dim=0)
            # net.eval()
            # with torch.no_grad():
            #     img_out=net(img_data)
            # img_out=img_out.squeeze()
            # print(img_out.shape)
            # # 将Torch张量转换为Numpy数组
            # img_out_np = img_out.cpu().numpy()

            # # 将数据从[0, 1]范围映射到[0, 255]，并转换类型到uint8
            # img_out_cv = (img_out_np * 255).astype(np.uint8)

            # # 检查img_out_cv的形状，将其调整为(height, width, channels)的形式
            # if len(img_out_cv.shape) == 2:  # 单通道图像
            #     pass
            # elif len(img_out_cv.shape) == 3:  # 多通道图像
            #     if img_out_cv.shape[0] == 3 or img_out_cv.shape[0] == 4:  # 如果是(C, H, W)，交换通道到最后一个维度
            #         img_out_cv = np.transpose(img_out_cv, (1, 2, 0))
            #     img_out_cv = cv2.cvtColor(img_out_cv, cv2.COLOR_RGB2BGR)  # 从RGB到BGR
            # else:
            #     raise ValueError("Unsupported shape for OpenCV:", img_out_cv.shape)
            # image_end=cv2.imread(f'{picture_path_out}/{i}.png')
            # writer.write(image_end)
            i+=1

    else:
        print('视频打开失败！')
    return fps

def binarize(tensor, threshold=0.5):
    return (tensor > threshold).float()

def merge_image_to_video(folder_name):
    fps = makevideo(video_path)
    firstflag = True
    for f1 in os.listdir(folder_name):
        filename = os.path.join(folder_name, f1)
        frame = cv2.imread(filename)
        if firstflag == True: 
            firstflag = False
            fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')
            img_size = (frame.shape[1], frame.shape[0])
            video = cv2.VideoWriter("/data/stu1/liuanqi/heart_2C/heart_myunet/video_out/output.mp4", fourcc, fps, img_size)
        frame = cv2.imread(filename)
        frame_suitable = cv2.resize(frame, (img_size[0], img_size[1]), interpolation=cv2.INTER_CUBIC)
        video.write(frame_suitable)
    video.release()

makevideo(video_path)

net=UNet().cuda()
weights='/data/stu1/liuanqi/heart_2C/heart_myunet/params/unet.pth'
if os.path.exists(weights):
    net.load_state_dict(torch.load(weights))
    print('successful')
else:
    print('no loading')

i=0
for test_image in os.listdir(video_to_picture):
    # 加载图像
    label_image=test_image.replace('.jpg','.png')
    img = keep_image_size_open(os.path.join(video_to_picture, test_image))
    img_data=transform(img).cuda()
    print(img_data.shape)
    img_data=torch.unsqueeze(img_data,dim=0)

    net.eval()
    with torch.no_grad():
        out=net(img_data)
    save_image(out,f'{to_picture_mask}/{i}.png')
    # output_binary = binarize(out, threshold=0.5)      # 模型输出二值化
    # img_end=img.convert('RGBA')
    # out = out.squeeze(0)
    # out_pil=to_pil_image(out)
    # out_end=out_pil.convert('RGBA')

    # image_end=Image.blend(img_end,out_end,0.4)
    # image_end.save(f'{save_path_end}/{i}.png')
    image=np.array(img)
    image=cv2.cvtColor(image,cv2.COLOR_RGB2BGR)
    print(image.shape)
    image.flags.writeable = True  # 将数组改为读写模式`
    mask = cv2.imread(f'{to_picture_mask}/{i}.png')
    image[:,:,2][mask[:,:,2]>50] = 255
    image[:,:,1][mask[:,:,2]>50] = 0
    image[:,:,0][mask[:,:,2]>50] = 0
    # # 将图像大小改变为 (600, 800)
    # image = cv2.resize(image,(800, 600))
    # print(image.shape)
    cv2.imwrite(f'{to_picture_mask_cover}/{i}.png',image)
    i+=1

merge_image_to_video(to_picture_mask_cover)

