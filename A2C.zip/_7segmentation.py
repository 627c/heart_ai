import os
import numpy as np
import cv2
import math
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from utils import *
from config import after_flash_image,after_flash_binary,to_picture_mask

i=0
for test_image in os.listdir(after_flash_image):
    points=[]
    label_image=test_image.replace('.jpg','.png')

    # 读取二值图像和原始灰度图像
    bin_img = cv2.imread(os.path.join(after_flash_binary, label_image),cv2.IMREAD_GRAYSCALE)
    gray_img = cv2.imread(os.path.join(after_flash_image, test_image),cv2.IMREAD_GRAYSCALE)
    red_mask=cv2.imread(os.path.join(to_picture_mask, label_image))
    red_mask = cv2.cvtColor(red_mask, cv2.COLOR_BGR2RGB)
    # red_mask=red_mask[0,:,:]
    # if red_mask.max()<=1.0:
    #     red_mask=red_mask*255
    # red_mask=red_mask.astype(np.uint8)
    if bin_img is None or gray_img is None:
        print(f"无法读取 {test_image}，请检查文件路径和格式")
        continue
    
    # 获取二值图像中白色的点的坐标
    _,bin_img=cv2.threshold(bin_img,127,255,cv2.THRESH_BINARY)
    points = np.argwhere(bin_img != 0)
    if i == 18:
        # 可视化检查 points
        plt.imshow(gray_img, cmap='gray')
        plt.scatter(points[:, 1], points[:, 0], color='red', s=1)
        plt.title("Points on Image")
        plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/vision/points.png')
        print("Image saved for i=18")
    # print(points[1000])
    
    # 找到y坐标最小的点（A点）
    # A_point = points[np.argmin(points[:, 0])]
    A_point=points[np.argmin(points[:,0])]
    # print(A_point)
    # 找到与A点x坐标相同但y坐标不同的点（B点）
    B_points = points[(points[:,1] == A_point[1]) & (points[:, 0] != A_point[0])]
    if B_points.size > 0:
        min_point = B_points[np.argmin(B_points[:,0])]  # 选择y坐标最大的B点
        for point in B_points:
            if point[0]>min_point[0] and (point[0]-min_point[0])<50:
                B_point=point
    _1line=[]
    for point in points:
        if point[0]==B_point[0]:
            _1line.append(point.tolist())
    _1line=np.array(_1line)
    # print(B_point)
    # 找出心尖区域
    three_region = []
    _points = []
    for point in points:
        if point[0] <= B_point[0] and point[0] >= A_point[0]:
            three_region.append(point)
        elif point[0]>B_point[0]:
            _points.append(point)
     # 增加调试信息
    if i==20:
        print(f"Processing image {i}: {test_image}")
        print(f"A_point: {A_point}")
        print(f"B_point: {B_point}")
        print(f"Number of points: {len(points)}")
        print(f"Three region points: {len(three_region)}")
        print(f"Other points: {len(_points)}")

    # print(A_point,B_point)
    # print(three_region)
    # print(_points)
    # 找中间点作为分左右两段的基点
    xmin_point = _1line[np.argmin(_1line[:,1])]
    xmax_point = _1line[np.argmax(_1line[:,1])]
    if i==20:
        print(_1line)
        print(xmin_point)
        print(xmax_point)
    # for point in points:
    #     if point[1]<xmin_point[1]:
    #         xmin_point=point
    # if xmin_points.size > 0:
    #     xmin_point = xmin_points[np.argmin(xmin_points[:, -1])]
    
    # xmax_point = points[0]
    # for point in points:
    #     if point[1]>xmin_point[1]:
    #         xmax_point=point
    # if xmax_points.size > 0:
    #     xmax_point = xmax_points[np.argmin(xmax_points[:, -1])]
    
    # 找到中间点，然后以他的x坐标作为基准分左右两个心肌带区域
    # print(xmax_point,xmin_point)
    xmid_point = (xmin_point + xmax_point) // 2
    # xmid_point=A_point
    # if i==20:
    #     print(B_points)
    #     print(xmin_point)
    #     print(xmax_point)
    #     print(xmid_point)
    right_points = []
    left_points = []
    for point in _points:
        if point[1] > xmid_point[1]:
            right_points.append(point)
        elif point[1]<=xmid_point[1]:
            left_points.append(point)
    right_points=np.array(right_points)
    left_points=np.array(left_points)
    # print(xmid_point[0])
    #找出右边y坐标最低，从而通过高度划分
    if right_points.size>1:
        ylow_point = right_points[np.argmax(right_points[:,0])]
    else:
        i+=1
        continue
    if left_points.size>1:
        _ylow_point = left_points[np.argmax(left_points[:,0])]
    else:
        i+=1
        continue
    # print(ylow_point)
    if i==30:
        print(right_points)
    second_ = (ylow_point[0] - B_point[0]) / 3 + B_point[0]
    first_ = 2 * (ylow_point[0] - B_point[0]) / 3 + B_point[0]
    if i==18:
        print(ylow_point,second_,first_)
    _2line=[]
    _3line=[]
    for point in right_points:
        if point[0]==int(first_):
            _2line.append(point)
        elif point[0]==int(second_):
            _3line.append(point)
    if i==18:
        print(_2line)
    region_1 = []
    region_2 = []
    region_3 = []
    for point in right_points:
        if point[0] > first_ and point[0] <= ylow_point[0]:
            region_1.append(point)
        elif point[0] > second_ and point[0] <= first_:
            region_2.append(point)
        else:
            region_3.append(point)
    # print(points)
    # print(region_1)
    # 找出左边y坐标最低，通过高度划分
    _second_ = (_ylow_point[0] - B_point[0]) / 3 + B_point[0]
    _first_ = 2 * (_ylow_point[0] - B_point[0]) / 3 + B_point[0]
    # print(left_points)
    # print(_first_,_second_)
    _4line=[]
    _5line=[]
    for point in left_points:
        if point[0]==int(_first_):
            _4line.append(point)
        elif point[0]==int(_second_):
            _5line.append(point)
    _region_1 = []
    _region_2 = []
    _region_3 = []
    for point in left_points:
        if point[0] > _first_ and point[0] <= _ylow_point[0]:
            _region_1.append(point)
        elif point[0] > _second_ and point[0] <= _first_:
            _region_2.append(point)
        else:
            _region_3.append(point)
    if i == 25:
        plt.figure(figsize=(10, 10))
        plt.imshow(red_mask,cmap='gray')

        # 可视化三个区域
        plt.scatter([p[1] for p in _1line], [p[0] for p in _1line], color='blue', s=5, label='1')
        plt.scatter([p[1] for p in _2line], [p[0] for p in _2line], color='green', s=5, label='2')
        plt.scatter([p[1] for p in _3line], [p[0] for p in _3line], color='red', s=5, label='3')

        plt.scatter([p[1] for p in _4line], [p[0] for p in _4line], color='cyan', s=5, label='4')
        plt.scatter([p[1] for p in _5line], [p[0] for p in _5line], color='magenta', s=5, label='5')

        plt.legend()
        plt.title("Regions on Image")
        plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/vision/red.png')
        plt.clf()
    if i == 25:
        plt.figure(figsize=(10, 10))
        plt.imshow(gray_img, cmap='gray')

        # 可视化三个区域
        plt.scatter([p[1] for p in region_1], [p[0] for p in region_1], color='blue', s=5, label='1')
        plt.scatter([p[1] for p in region_2], [p[0] for p in region_2], color='green', s=5, label='2')
        plt.scatter([p[1] for p in region_3], [p[0] for p in region_3], color='red', s=5, label='3')

        plt.scatter([p[1] for p in _region_1], [p[0] for p in _region_1], color='cyan', s=5, label='4')
        plt.scatter([p[1] for p in _region_2], [p[0] for p in _region_2], color='magenta', s=5, label='5')
        plt.scatter([p[1] for p in _region_3], [p[0] for p in _region_3], color='yellow', s=5, label='6')

        plt.scatter([p[1] for p in three_region], [p[0] for p in three_region], color='orange', s=5, label='Apical')

        plt.legend()
        plt.title("Regions on Image")
        plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/vision/cover.png')
    i+=1
