import cv2
import numpy as np

def detect_blank_frames(video_path):
    """
    检测视频中的空白帧

    参数:
    video_path: 视频文件路径
    threshold: 用于决定是否为空白帧的像素值阈值

    返回:
    blank_frames: 空白帧的位置列表
    """
    cap = cv2.VideoCapture(video_path)
    blank_frames = []
    if cap.isOpened():
        fps = cap.get(cv2.CAP_PROP_FPS)  # 获取视频的FPS（帧率）
        print(fps)
        i=0
        intensity=[]
        while True:
            ret,img_src=cap.read()
            if not ret:break
            gray_frame = cv2.cvtColor(img_src, cv2.COLOR_BGR2GRAY)
        
            # 计算帧中所有像素的平均值
            mean_pixel_value = np.mean(gray_frame)
            print(mean_pixel_value)
            if mean_pixel_value<1:
                print(i)
            intensity.append(mean_pixel_value)
            i+=1
    cap.release()
    threshold=max(intensity)-3
    t=0
    for t in range(i):
        if intensity[t]>threshold:
            blank_frames.append(t)   
    return blank_frames
