import os
from torch import nn,optim
import torch
from torch.utils.data import DataLoader
from data import *
from net2 import *
from torchvision.utils import save_image

class DiceBCELoss(nn.Module):
    def __init__(self, weight=None, reduction='mean',dice_weight=0.7):
        super(DiceBCELoss, self).__init__()
        self.bce = nn.BCELoss(weight, reduction=reduction)
        self.dice_weight=dice_weight      #dice损失的权重
    def forward(self, inputs, targets, smooth=1e-5):
        
        # BCE Loss
        bce = self.bce(inputs, targets)
        
        # Dice Loss
        inputs = torch.sigmoid(inputs)       
        inputs = inputs.view(-1)
        targets = targets.view(-1)
        
        intersection = (inputs * targets).sum()                            
        dice_loss = 1 - (2.*intersection + smooth)/(inputs.sum() + targets.sum() + smooth)  
        
        # Combined loss
        dice_bce = (1-self.dice_weight)*bce+self.dice_weight*dice_loss
        
        return dice_bce
    
# validate函数
def validate(model, data_loader, loss_function, device):
    model.eval()  # 将模型设置为评估模式
    total_loss = 0.0
    with torch.no_grad():  # 禁用梯度计算
        for i, (image, segment_image) in enumerate(data_loader):
            image, segment_image = image.to(device), segment_image.to(device)
            
            # 正向传播获取输出
            out_image = model(image)
            
            # 计算损失
            loss = loss_fun(out_image, segment_image)
            total_loss += loss.item()
    
    avg_loss = total_loss / len(data_loader)  # 计算平均损失
    model.train()  # 恢复模型到训练模式
    return avg_loss

class EarlyStopping:
    def __init__(self, patience, min_delta):
        """
        :param patience: (int) 超过这么多个epoch没有改进就停止训练.
        :param min_delta: (float) 表示被认为是改进的最小变化。
        """
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.early_stop = False

    def __call__(self, val_loss):
        if self.best_loss is None:
            self.best_loss = val_loss
        elif self.best_loss - val_loss > self.min_delta:
            self.best_loss = val_loss
            # 当验证损失下降时，重置计数器
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
weight_path='/data/stu1/liuanqi/heart_2C/heart_myunet/params/unet.pth'
data_path='/data/stu1/liuanqi/heart_2C/heart_myunet/train_data'
vdata_path='/data/stu1/liuanqi/heart_2C/heart_myunet/test_data'
save_path='/data/stu1/liuanqi/heart_2C/heart_myunet/train_image'

if __name__== '__main__':
    early_stopping = EarlyStopping(patience=10, min_delta=0.0001)
    data_loader=DataLoader(MyDataset(data_path),batch_size=8,shuffle=True)
    validation_data_loader=DataLoader(MyValidDataset(vdata_path),batch_size=8,shuffle=True)
    net=UNet().to(device)
    if os.path.exists(weight_path):
        net.load_state_dict(torch.load(weight_path))
        print('successful load weight')
    else:
        print('not successful load weight')

    #设置优化器
    opt=optim.Adam(net.parameters())
    # 设置学习率调整策略
    scheduler = torch.optim.lr_scheduler.StepLR(opt, step_size=10, gamma=0.1)
    loss_fun=DiceBCELoss().to(device)
    for epoch in range(100):
        train_losses=[]
        for i,(image,segment_image) in enumerate(data_loader):
            image,segment_image=image.to(device),segment_image.to(device)

            out_image=net(image)
            train_loss=loss_fun(out_image,segment_image)

            opt.zero_grad()
            train_loss.backward()
            opt.step()
            train_losses.append(train_loss.item())

            if i%5==0:
                print(f'{epoch}-{i}-train_loss===>>{train_loss.item()}')

            if i%50==0:
                _image=image[0].detach().cpu()
                _segment_image=segment_image[0].detach().cpu()
                _out_image=out_image[0].detach().cpu()

                img=torch.stack([_image,_segment_image,_out_image],dim=0)
                save_image(img,f'{save_path}/{i}.png')
        scheduler.step()
        print(f"Epoch{epoch+1}/{100},Learning Rate :{opt.param_groups[0]['lr']:.5f}")
# 计算平均训练损失
        avg_train_loss = sum(train_losses) / len(train_losses)
        previous_best=early_stopping.best_loss
        val_loss = validate(net, validation_data_loader, loss_fun, device)
        
        # 打印验证损失信息
        print(f'Epoch {epoch} - val_loss: {val_loss}')

        # 早期停止的逻辑
        early_stopping(val_loss)
        current_best=early_stopping.best_loss
        if early_stopping.early_stop:
            print(f"Early stopping at epoch {epoch}")
            break
        
        # 可以选择在此处保存模型，特别是如果这是最好的性能
        if previous_best is None or current_best < previous_best:
            torch.save(net.state_dict(), weight_path)
            print(f"Saved model checkpoint with val_loss:{current_best}")

