import cv2
import numpy as np
import matplotlib.pyplot as plt

def load_image(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    return image

def fft_image(image):
    f = np.fft.fft2(image)
    fshift = np.fft.fftshift(f)
    magnitude_spectrum = 20*np.log(np.abs(fshift) + 1)  # 加1避免对0取对数
    power_spectrum = np.abs(fshift)**2
    return fshift, magnitude_spectrum, power_spectrum

def apply_filter(fshift, type='high', size=50):
    rows, cols = fshift.shape
    print(rows,cols)
    crow, ccol = rows//2, cols//2
    if type == 'high':
        mask = np.ones((rows, cols), np.uint8)
        mask[crow-size:crow+size, ccol-size:ccol+size] = 0
    else:
        mask = np.zeros((rows, cols), np.uint8)
        mask[crow-size:crow+size, ccol-size:ccol+size] = 1
        mask=1-mask
    f_filtered = fshift * mask
    return f_filtered

def ifft_image(f_ishift):
    f_ishift = np.fft.ifftshift(f_ishift)
    img_back = np.fft.ifft2(f_ishift)
    img_back = np.abs(img_back)
    return img_back

def main():
    image_path = '/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/image/55.jpg'
    image = load_image(image_path)

    fshift, magnitude_spectrum, power_spectrum = fft_image(image)

    # 显示幅度谱和功率谱
    plt.figure(figsize=(18, 6))
    plt.subplot(131), plt.imshow(image, cmap='gray'), plt.title('Original Image',fontsize=18), plt.xticks([]), plt.yticks([])
    plt.subplot(132), plt.imshow(magnitude_spectrum, cmap='gray'), plt.title('Magnitude Spectrum',fontsize=22), plt.xticks([]), plt.yticks([])
    plt.subplot(133), plt.imshow(20*np.log10(power_spectrum + 1), cmap='gray'), plt.title('Power Spectrum Density',fontsize=22), plt.xticks([]), plt.yticks([])
    plt.show()
    plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/pinpu2.png')
    plt.close()
    # 应用滤波器
    f_filtered = apply_filter(fshift.copy(), type='high', size=1)

    img_filtered = ifft_image(f_filtered)

    plt.subplot(121),plt.imshow(image, cmap = 'gray'), plt.title('Original Image'), plt.xticks([]), plt.yticks([])
    plt.subplot(122),plt.imshow(img_filtered, cmap = 'gray'), plt.title('Filtered Image'), plt.xticks([]), plt.yticks([])
    plt.show()
    plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/image1.png')

if __name__ == '__main__':
    main()