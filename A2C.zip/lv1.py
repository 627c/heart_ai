import cv2
import numpy as np
import matplotlib.pyplot as plt

def load_image(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    return image

def fft_image(image):
    f = np.fft.fft2(image)
    fshift = np.fft.fftshift(f)
    magnitude_spectrum = np.abs(fshift)
    power_spectrum = magnitude_spectrum ** 2
    return fshift, magnitude_spectrum, power_spectrum

def radial_profile(data, center):
    y, x = np.indices((data.shape))  # 获取网格的索引
    r = np.sqrt((x - center[1])**2 + (y - center[0])**2)
    r = r.astype(np.int64)

    tbin = np.bincount(r.ravel(), data.ravel())  # 径向求和
    nr = np.bincount(r.ravel())  # 计数
    radialprofile = tbin / nr
    return radialprofile

def plot_radial_profiles(magnitude_spectrum, power_spectrum):
    center = (magnitude_spectrum.shape[0]//2, magnitude_spectrum.shape[1]//2)
    radial_magnitude = radial_profile(magnitude_spectrum, center)
    radial_power = radial_profile(power_spectrum, center)
    
    freqs = np.linspace(0, np.max(radial_magnitude.shape), num=len(radial_magnitude))
    
    plt.figure(figsize=(12, 5))
    plt.subplot(121)
    plt.plot(freqs, radial_magnitude)
    plt.title('Radial Magnitude Spectrum')
    plt.xlabel('Frequency')
    plt.ylabel('Magnitude')
    
    plt.subplot(122)
    plt.plot(freqs, radial_power)
    plt.title('Radial Power Spectrum Density')
    plt.xlabel('Frequency')
    plt.ylabel('Power')

    plt.show()

def main():
    image_path = '/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/image/55.jpg'
    image = load_image(image_path)

    fshift, magnitude_spectrum, power_spectrum = fft_image(image)

    plot_radial_profiles(magnitude_spectrum, power_spectrum)
    plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/pinpu3.png')

if __name__ == '__main__':
    main()