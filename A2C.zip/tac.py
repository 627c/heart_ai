import cv2
import numpy as np
import os
import shutil
import matplotlib.pyplot as plt

from net2 import *
from utils import *
from train import *
from data import *

from torchvision.utils import save_image
from config import flash,video_to_picture,after_flash_image,after_flash_binary,after_flash_cover

def binarize(tensor, threshold=0.5):
    return (tensor > threshold).float()
def clear_folder(folder_path):
    """
    清除指定文件夹中的所有文件。
    """
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)  # 删除文件或符号链接
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)  # 删除文件夹及其内容
        except Exception as e:
            print(f"Failed to delete {file_path}. Reason: {e}")

clear_folder(after_flash_image)
clear_folder(after_flash_binary)
clear_folder(after_flash_cover)

net=UNet().cuda()
weights='/data/stu1/liuanqi/heart_2C/heart_myunet/params/unet.pth'
if os.path.exists(weights):
    net.load_state_dict(torch.load(weights))
    print('successful')
else:
    print('no loading')

i=0
tac_list=[]
for test_image in os.listdir(video_to_picture):
    # 加载图像
    img = keep_image_size_open(os.path.join(video_to_picture, test_image))
    img_data=transform(img).cuda()
    img_data=torch.unsqueeze(img_data,dim=0)
    net.eval()
    with torch.no_grad():
        out=net(img_data)
    img_=np.array(img)
    img_=img_.astype(np.uint8)
    img_=cv2.cvtColor(img_,cv2.COLOR_RGB2GRAY)
    if i>flash:
        cv2.imwrite(f'{after_flash_image}/{i}.jpg',img_)
    mask_data=out.squeeze()
    mask_data=mask_data[0,:,:]
    mask_data=mask_data.cpu().detach()
    mask_data=mask_data.numpy()
    if mask_data.max()<=1.0:
        mask_data=mask_data*255
    mask_data=mask_data.astype(np.uint8)
    # save_image(mask_data,f'{save_path1}/{i}.png')
    # 提取红色通道作为二值化掩膜（假设掩膜主要是红色）
    ret,binary_mask = cv2.threshold(mask_data, 50, 255, cv2.THRESH_BINARY)
    if i>flash:
        cv2.imwrite(f'{after_flash_binary}/{i}.png',binary_mask)
    #确保 binary_mask 是 uint8 类型并且是单通道
    if binary_mask.dtype != np.uint8:
        binary_mask = binary_mask.astype(np.uint8)
    # 使用二值化掩膜来选取原始图像中的分割区域
    print(img_.shape)
    print("1",binary_mask.shape)
    segmented_region = cv2.bitwise_and(img_, img_, mask=binary_mask)
    segmented_region=np.squeeze(segmented_region)
    print(segmented_region.shape)
    if i>flash:
        cv2.imwrite(f'{after_flash_cover}/{i}.png',segmented_region)
    i+=1
    #     mean_intensity = np.mean(segmented_region[binary_mask > 0])
    #     tac_list.append(mean_intensity)
    #     i+=1

    # return tac_list
