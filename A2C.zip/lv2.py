import numpy as np  
import cv2  
import pywt  

# 读取图像（请替换为你的图像文件路径）  
image_path = '/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/image/55.jpg'  
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)  

# 确保图像读取成功  
if image is None:  
    print('Could not open or find the image')  
    exit()  

# 小波变换去噪  
# 选择小波类型（例如：'haar'，'db4'，'sym4'等）  
wavelet = 'coif2'  

# 进行小波变换，这里使用二维的小波变换  
coeffs = pywt.wavedec2(image, wavelet, level=1)  # 只进行一层分解  

# coeffs 是一个元组，包含近似系数和三个细节系数（对于一层分解）  
# coeffs[0] 是近似系数，coeffs[1] 是细节系数，细节系数是一个三元组（cH, cV, cD）  
# 使用零化细节系数  
cA, (cH, cV, cD) = coeffs  # 解包近似系数与细节系数  

# 将细节系数替换为零  
# cH = np.zeros_like(cH)  
# cV = np.zeros_like(cV)  
# cD = np.zeros_like(cD)  

# 重新打包系数  
coeffs = (cA, (cH, cV, cD))  

# 使用小波逆变换重建图像  
reconstructed_image = pywt.waverec2(coeffs, wavelet)  

# 将重建的图像转换为 uint8 格式  
# 由于小波变换之后的值可能超出 0-255 范围，需先归一化  
reconstructed_image = cv2.normalize(reconstructed_image, None, 0, 255, cv2.NORM_MINMAX)  
reconstructed_image = np.uint8(reconstructed_image)  

# 双边滤波器进一步细化图像  
d = 3  
sigmaColor = 30  
sigmaSpace = 50  
refined_image = cv2.bilateralFilter(reconstructed_image, d, sigmaColor, sigmaSpace)  

# 显示或保存图像  
cv2.waitKey(0)  
cv2.imwrite('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/image2.png', reconstructed_image)
cv2.imwrite('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/image3.png', refined_image)