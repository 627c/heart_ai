import os
import numpy as np
import cv2
import math
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
# from config import fps,after_flash_image,after_flash_binary

def detect_blank_frames(video_path):
    """
    检测视频中的空白帧

    参数:
    video_path: 视频文件路径
    threshold: 用于决定是否为空白帧的像素值阈值

    返回:
    blank_frames: 空白帧的位置列表
    """
    cap = cv2.VideoCapture(video_path)
    blank_frames = []
    if cap.isOpened():
        fps = cap.get(cv2.CAP_PROP_FPS)  # 获取视频的FPS（帧率）
        print(fps)
        i=0
        intensity=[]
        while True:
            ret,img_src=cap.read()
            if not ret:break
            gray_frame = cv2.cvtColor(img_src, cv2.COLOR_BGR2GRAY)
        
            # 计算帧中所有像素的平均值
            mean_pixel_value = np.mean(gray_frame)
            print(mean_pixel_value)
            if mean_pixel_value<1:
                print(i)
            intensity.append(mean_pixel_value)
            i+=1
    cap.release()
    threshold=max(intensity)-3
    t=0
    for t in range(i):
        if intensity[t]>threshold:
            blank_frames.append(t)   
    return blank_frames

video_path='/data/stu1/liuanqi/heart_2C/heart_myunet/video /病例五.avi'
video_to_picture='/data/stu1/liuanqi/heart_2C/heart_myunet/video_make_picture/1'
to_picture_mask='/data/stu1/liuanqi/heart_2C/heart_myunet/video_make_picture/1_out'
to_picture_mask_cover='/data/stu1/liuanqi/heart_2C/heart_myunet/video_make_picture/1_out_end'

after_flash_image='/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/image'
after_flash_binary='/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/binary'
after_flash_cover='/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_cover'

blank_frames = detect_blank_frames(video_path)
print(f"空白帧的位置: {blank_frames}")
flash=blank_frames[-1]
#获取帧率
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print("Error opening video stream or file")
fps = cap.get(cv2.CAP_PROP_FPS)  # 获取视频的FPS（帧率）
print(fps)

def clean(serie):
    output = serie[(np.isnan(serie) == False) & (np.isinf(serie) == False)]
    return output

def calculate_intensity(image, points):
    """Calculate the average intensity for the given points in the image."""
    sensity=[]
    for point in points:
        sensity.append(image[point])
    return np.mean(sensity)
def main(tac_list,setac_path):

    first_intensity=tac_list[0]
    first_intensity_db=np.abs(10*np.log10(first_intensity))
    tac_list_=np.array(tac_list)
    mean_intensity=np.mean(tac_list_)
    mean_intensity_db=np.abs(10*np.log10(mean_intensity))
    tac_list_db=(10*np.log10(np.maximum(tac_list_,1e-7)/first_intensity))+first_intensity_db
    tac_list_db=tac_list_db.tolist()

    return tac_list_db,mean_intensity_db


i=0
intensity_region_a_1=[]
intensity_region_a_2=[]
intensity_region_a_3=[]
intensity_region_a_4=[]
intensity_region_a_5=[]
intensity_region_a_6=[]
intensity_region_a_7=[]
intensity_region_a_8=[]
intensity_region_a_9=[]
intensity_region_a_10=[]

intensity_region_1_1=[]
intensity_region_1_2=[]
intensity_region_1_3=[]
intensity_region_1_4=[]
intensity_region_1_5=[]
intensity_region_1_6=[]
intensity_region_1_7=[]
intensity_region_1_8=[]
intensity_region_1_9=[]
intensity_region_1_10=[]

intensity_region_2_1=[]
intensity_region_2_2=[]
intensity_region_2_3=[]
intensity_region_2_4=[]
intensity_region_2_5=[]
intensity_region_2_6=[]
intensity_region_2_7=[]
intensity_region_2_8=[]
intensity_region_2_9=[]
intensity_region_2_10=[]

intensity_region_3_1=[]
intensity_region_3_2=[]
intensity_region_3_3=[]
intensity_region_3_4=[]
intensity_region_3_5=[]
intensity_region_3_6=[]
intensity_region_3_7=[]
intensity_region_3_8=[]
intensity_region_3_9=[]
intensity_region_3_10=[]

intensity__region_1_1=[]
intensity__region_1_2=[]
intensity__region_1_3=[]
intensity__region_1_4=[]
intensity__region_1_5=[]
intensity__region_1_6=[]
intensity__region_1_7=[]
intensity__region_1_8=[]
intensity__region_1_9=[]
intensity__region_1_10=[]

intensity__region_2_1=[]
intensity__region_2_2=[]
intensity__region_2_3=[]
intensity__region_2_4=[]
intensity__region_2_5=[]
intensity__region_2_6=[]
intensity__region_2_7=[]
intensity__region_2_8=[]
intensity__region_2_9=[]
intensity__region_2_10=[]

intensity__region_3_1=[]
intensity__region_3_2=[]
intensity__region_3_3=[]
intensity__region_3_4=[]
intensity__region_3_5=[]
intensity__region_3_6=[]
intensity__region_3_7=[]
intensity__region_3_8=[]
intensity__region_3_9=[]
intensity__region_3_10=[]

intensity_three_region=[]
for test_image in os.listdir(after_flash_image):
    points=[]
    label_image=test_image.replace('.jpg','.png')

    # 读取二值图像和原始灰度图像
    bin_img = cv2.imread(os.path.join(after_flash_binary, label_image),cv2.IMREAD_GRAYSCALE)
    gray_img = cv2.imread(os.path.join(after_flash_image, test_image),cv2.IMREAD_GRAYSCALE)
    
    if bin_img is None or gray_img is None:
        print(f"无法读取 {test_image}，请检查文件路径和格式")
        continue
    
    # 获取二值图像中白色的点的坐标
    _,bin_img=cv2.threshold(bin_img,127,255,cv2.THRESH_BINARY)
    points = np.argwhere(bin_img != 0)
    # print(points[1000])
    if i==0:
      # 可视化检查 points
    # plt.imshow(gray_img, cmap='gray')
        plt.scatter(points[:, 0], points[:, 1], color='red', s=1)
        plt.title("Points on Image")
        plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/verify/points.png')


    # 找到y坐标最小的点（A点）
    # A_point = points[np.argmin(points[:, 0])]
    A_point=points[np.argmin(points[:,0])]
    # print(A_point)
    # 找到与A点x坐标相同但y坐标不同的点（B点）
    B_points = points[(points[:,1] == A_point[1]) & (points[:, 0] != A_point[0])]
    if B_points.size > 0:
        min_point = B_points[np.argmin(B_points[:,0])]  # 选择y坐标最大的B点
        for point in B_points:
            if point[0]>min_point[0] and (point[0]-min_point[0])<20:
                B_point=point
    # print(B_point)
    # 找出心尖区域
    _1line=[]
    for point in points:
        if point[0]==B_point[0]:
            _1line.append(point.tolist())
    _1line=np.array(_1line)
    three_region = []
    _points = []
    for point in points:
        if point[0] <= B_point[0] and point[0] >= A_point[0]:
            three_region.append(point)
        elif point[0]>B_point[0]:
            _points.append(point)
    # if i==0:
    #     print(f"Processing image {i}: {test_image}")
    #     print(f"A_point: {A_point}")
    #     print(f"B_point: {B_point}")
    #     print(f"Number of points: {len(points)}")
    #     print(f"Three region points: {len(three_region)}")
    #     print(f"Other points: {len(_points)}")
    # print(A_point,B_point)
    # print(three_region)
    # print(_points)
    # 找中间点作为分左右两段的基点
    xmin_point = _1line[np.argmin(_1line[:,1])]
    xmax_point = _1line[np.argmax(_1line[:,1])]
    # if i==0:
    #     print(_1line)
    #     print(f'B_points:{B_points}')
    #     print(xmin_point)
    #     print(xmax_point)
    # for point in points:
    #     if point[1]<xmin_point[1]:
    #         xmin_point=point
    # if xmin_points.size > 0:
    #     xmin_point = xmin_points[np.argmin(xmin_points[:, -1])]
    
    # xmax_point = points[0]
    # for point in points:
    #     if point[1]>xmin_point[1]:
    #         xmax_point=point
    # if xmax_points.size > 0:
    #     xmax_point = xmax_points[np.argmin(xmax_points[:, -1])]
    
    # 找到中间点，然后以他的x坐标作为基准分左右两个心肌带区域
    # print(xmax_point,xmin_point)
    xmid_point = (xmin_point + xmax_point) // 2
    # xmid_point=A_point
    # if i==0:
    #     print(xmax_point)
    #     print(xmin_point)
    right_points = []
    left_points = []
    for point in _points:
        if point[1] > xmid_point[1]:
            right_points.append(point)
        elif point[1]<=xmid_point[1]:
            left_points.append(point)
    right_points=np.array(right_points)
    left_points=np.array(left_points)
    # print(right_points)
    # print(xmid_point[0])
    # 找出右边y坐标最低，从而通过高度划分
    if right_points.size>1:
        ylow_point = right_points[np.argmax(right_points[:,0])]
    else:
        i+=1
        continue
    if left_points.size>1:
        _ylow_point = left_points[np.argmax(left_points[:,0])]
    else:
        i+=1
        continue
    # print(ylow_point)
    second_ = (ylow_point[0] - B_point[0]) / 3 + B_point[0]
    first_ = 2 * (ylow_point[0] - B_point[0]) / 3 + B_point[0]
    # print(ylow_point,second_,first_)
    region_1 = []
    region_2 = []
    region_3 = []
    x=0
    for point in right_points:
        if point[0] > first_ and point[0] <= ylow_point[0]:
            region_1.append(point)
            x+=1
        elif point[0] > second_ and point[0] <= first_:
            region_2.append(point)
        else:
            region_3.append(point)

    region_1_1=[]
    region_1_2=[]
    region_1_3=[]
    region_1_4=[]
    region_1_5=[]
    region_1_6=[]
    region_1_7=[]
    region_1_8=[]
    region_1_9=[]
    region_1_10=[]
    region_2_1=[]
    region_2_2=[]
    region_2_3=[]
    region_2_4=[]
    region_2_5=[]
    region_2_6=[]
    region_2_7=[]
    region_2_8=[]
    region_2_9=[]
    region_2_10=[]
    region_3_1=[]
    region_3_2=[]
    region_3_3=[]
    region_3_4=[]
    region_3_5=[]
    region_3_6=[]
    region_3_7=[]
    region_3_8=[]
    region_3_9=[]
    region_3_10=[]
    # print(points)
    # print(region_1)
    # 找出左边y坐标最低，通过高度划分
    _second_ = (_ylow_point[0] - B_point[0]) / 3 + B_point[0]
    _first_ = 2 * (_ylow_point[0] - B_point[0]) / 3 + B_point[0]
    # print(left_points)
    # print(_first_,_second_)
    _region_1 = []
    _region_2 = []
    _region_3 = []
    for point in left_points:
        if point[0] > _first_ and point[0] <= _ylow_point[0]:
            _region_1.append(point)
        elif point[0] > _second_ and point[0] <= _first_:
            _region_2.append(point)
        else:
            _region_3.append(point)

    if i==25:
        print(f"r{_region_2}")
        for point in _region_2:
            print(f"1{point}")

    _region_1_1=[]
    _region_1_2=[]
    _region_1_3=[]
    _region_1_4=[]
    _region_1_5=[]
    _region_1_6=[]
    _region_1_7=[]
    _region_1_8=[]
    _region_1_9=[]
    _region_1_10=[]
    _region_2_1=[]
    _region_2_2=[]
    _region_2_3=[]
    _region_2_4=[]
    _region_2_5=[]
    _region_2_6=[]
    _region_2_7=[]
    _region_2_8=[]
    _region_2_9=[]
    _region_2_10=[]
    _region_3_1=[]
    _region_3_2=[]
    _region_3_3=[]
    _region_3_4=[]
    _region_3_5=[]
    _region_3_6=[]
    _region_3_7=[]
    _region_3_8=[]
    _region_3_9=[]
    _region_3_10=[]

    _region_three_1=[]
    _region_three_2=[]
    _region_three_3=[]
    _region_three_4=[]
    _region_three_5=[]
    _region_three_6=[]
    _region_three_7=[]
    _region_three_8=[]
    _region_three_9=[]
    _region_three_10=[]
    # if i==25:
    maxn=_region_1[0]
    minn=_region_1[0]

    for point in _region_1:
        if point[0]>maxn[0]:
            maxn=point
        if point[0]<minn[0]:
            minn=point
    zhong=(maxn[0]-minn[0])/10
    t=0
    for point in _region_1:
        if point[0]>=minn[0] and point[0]<=minn[0]+zhong:
            _region_1_1.append(point)
        if point[0]>minn[0]+zhong and point[0]<=minn[0]+2*zhong:
            _region_1_2.append(point)
        if point[0]>minn[0]+2*zhong and point[0]<=minn[0]+3*zhong:
            _region_1_3.append(point)
        if point[0]>minn[0]+3*zhong and point[0]<=minn[0]+4*zhong:
            _region_1_4.append(point)
        if point[0]>minn[0]+4*zhong and point[0]<=minn[0]+5*zhong:
            _region_1_5.append(point)
        if point[0]>minn[0]+5*zhong and point[0]<=minn[0]+6*zhong:
            _region_1_6.append(point)
        if point[0]>minn[0]+6*zhong and point[0]<=minn[0]+7*zhong:
            _region_1_7.append(point)
        if point[0]>minn[0]+7*zhong and point[0]<=minn[0]+8*zhong:
            _region_1_8.append(point)
        if point[0]>minn[0]+8*zhong and point[0]<=minn[0]+9*zhong:
            _region_1_9.append(point)
        if point[0]>minn[0]+9*zhong and point[0]<=minn[0]+10*zhong:
            _region_1_10.append(point)


    maxn=_region_2[0]
    minn=_region_2[0]

    for point in _region_2:
        if point[0]>maxn[0]:
            maxn=point
        if point[0]<minn[0]:
            minn=point
    zhong=(maxn[0]-minn[0])/10

    for point in _region_2:
        if point[0]>=minn[0] and point[0]<=minn[0]+zhong:
            _region_2_1.append(point)
        if point[0]>minn[0]+zhong and point[0]<=minn[0]+2*zhong:
            _region_2_2.append(point)
        if point[0]>minn[0]+2*zhong and point[0]<=minn[0]+3*zhong:
            _region_2_3.append(point)
        if point[0]>minn[0]+3*zhong and point[0]<=minn[0]+4*zhong:
            _region_2_4.append(point)
        if point[0]>minn[0]+4*zhong and point[0]<=minn[0]+5*zhong:
            _region_2_5.append(point)
        if point[0]>minn[0]+5*zhong and point[0]<=minn[0]+6*zhong:
            _region_2_6.append(point)
        if point[0]>minn[0]+6*zhong and point[0]<=minn[0]+7*zhong:
            _region_2_7.append(point)
        if point[0]>minn[0]+7*zhong and point[0]<=minn[0]+8*zhong:
            _region_2_8.append(point)
        if point[0]>minn[0]+8*zhong and point[0]<=minn[0]+9*zhong:
            _region_2_9.append(point)
        if point[0]>minn[0]+9*zhong and point[0]<=minn[0]+10*zhong:
            _region_2_10.append(point)

    maxn=_region_3[0]
    minn=_region_3[0]

    for point in _region_3:
        if point[0]>maxn[0]:
            maxn=point
        if point[0]<minn[0]:
            minn=point
    zhong=(maxn[0]-minn[0])/10

    for point in _region_3:
        if point[0]>=minn[0]+0*zhong and point[0]<=minn[0]+1*zhong:
            _region_3_1.append(point)
        if point[0]>minn[0]+1*zhong and point[0]<=minn[0]+2*zhong:
            _region_3_2.append(point)
        if point[0]>minn[0]+2*zhong and point[0]<=minn[0]+3*zhong:
            _region_3_3.append(point)
        if point[0]>minn[0]+3*zhong and point[0]<=minn[0]+4*zhong:
            _region_3_4.append(point)
        if point[0]>minn[0]+4*zhong and point[0]<=minn[0]+5*zhong:
            _region_3_5.append(point)
        if point[0]>minn[0]+5*zhong and point[0]<=minn[0]+6*zhong:
            _region_3_6.append(point)
        if point[0]>minn[0]+6*zhong and point[0]<=minn[0]+7*zhong:
            _region_3_7.append(point)
        if point[0]>minn[0]+7*zhong and point[0]<=minn[0]+8*zhong:
            _region_3_8.append(point)
        if point[0]>minn[0]+8*zhong and point[0]<=minn[0]+9*zhong:
            _region_3_9.append(point)
        if point[0]>minn[0]+9*zhong and point[0]<=minn[0]+10*zhong:
            _region_3_10.append(point)

    maxn=region_1[0]
    minn=region_1[0]

    for point in region_1:
        if point[0]>maxn[0]:
            maxn=point
        if point[0]<minn[0]:
            minn=point
    zhong=(maxn[0]-minn[0])/10

    for point in region_1:
        if point[0]>=minn[0]+0*zhong and point[0]<=minn[0]+1*zhong:
            region_1_1.append(point)
        if point[0]>minn[0]+1*zhong and point[0]<=minn[0]+2*zhong:
            region_1_2.append(point)
        if point[0]>minn[0]+2*zhong and point[0]<=minn[0]+3*zhong:
            region_1_3.append(point)
            t+=1
        if point[0]>minn[0]+3*zhong and point[0]<=minn[0]+4*zhong:
            region_1_4.append(point)
        if point[0]>minn[0]+4*zhong and point[0]<=minn[0]+5*zhong:
            region_1_5.append(point)
        if point[0]>minn[0]+5*zhong and point[0]<=minn[0]+6*zhong:
            region_1_6.append(point)
        if point[0]>minn[0]+6*zhong and point[0]<=minn[0]+7*zhong:
            region_1_7.append(point)
        if point[0]>minn[0]+7*zhong and point[0]<=minn[0]+8*zhong:
            region_1_8.append(point)
        if point[0]>minn[0]+8*zhong and point[0]<=minn[0]+9*zhong:
            region_1_9.append(point)
        if point[0]>minn[0]+9*zhong and point[0]<=minn[0]+10*zhong:
            region_1_10.append(point)

    maxn=region_2[0]
    minn=region_2[0]

    for point in region_2:
        if point[0]>maxn[0]:
            maxn=point
        if point[0]<minn[0]:
            minn=point
    zhong=(maxn[0]-minn[0])/10

    for point in region_2:
        if point[0]>=minn[0]+0*zhong and point[0]<=minn[0]+1*zhong:
            region_2_1.append(point)
        if point[0]>minn[0]+1*zhong and point[0]<=minn[0]+2*zhong:
            region_2_2.append(point)
        if point[0]>minn[0]+2*zhong and point[0]<=minn[0]+3*zhong:
            region_2_3.append(point)
        if point[0]>minn[0]+3*zhong and point[0]<=minn[0]+4*zhong:
            region_2_4.append(point)
        if point[0]>minn[0]+4*zhong and point[0]<=minn[0]+5*zhong:
            region_2_5.append(point)
        if point[0]>minn[0]+5*zhong and point[0]<=minn[0]+6*zhong:
            region_2_6.append(point)
        if point[0]>minn[0]+6*zhong and point[0]<=minn[0]+7*zhong:
            region_2_7.append(point)
        if point[0]>minn[0]+7*zhong and point[0]<=minn[0]+8*zhong:
            region_2_8.append(point)
        if point[0]>minn[0]+8*zhong and point[0]<=minn[0]+9*zhong:
            region_2_9.append(point)
        if point[0]>minn[0]+9*zhong and point[0]<=minn[0]+10*zhong:
            region_2_10.append(point)

    maxn=region_3[0]
    minn=region_3[0]

    for point in region_3:
        if point[0]>maxn[0]:
            maxn=point
        if point[0]<minn[0]:
            minn=point
    zhong=(maxn[0]-minn[0])/10

    for point in region_3:
        if point[0]>=minn[0]+0*zhong and point[0]<=minn[0]+1*zhong:
            region_3_1.append(point)
        if point[0]>minn[0]+1*zhong and point[0]<=minn[0]+2*zhong:
            region_3_2.append(point)
        if point[0]>minn[0]+2*zhong and point[0]<=minn[0]+3*zhong:
            region_3_3.append(point)
        if point[0]>minn[0]+3*zhong and point[0]<=minn[0]+4*zhong:
            region_3_4.append(point)
        if point[0]>minn[0]+4*zhong and point[0]<=minn[0]+5*zhong:
            region_3_5.append(point)
        if point[0]>minn[0]+5*zhong and point[0]<=minn[0]+6*zhong:
            region_3_6.append(point)
        if point[0]>minn[0]+6*zhong and point[0]<=minn[0]+7*zhong:
            region_3_7.append(point)
        if point[0]>minn[0]+7*zhong and point[0]<=minn[0]+8*zhong:
            region_3_8.append(point)
        if point[0]>minn[0]+8*zhong and point[0]<=minn[0]+9*zhong:
            region_3_9.append(point)
        if point[0]>minn[0]+9*zhong and point[0]<=minn[0]+10*zhong:
            region_3_10.append(point)

    maxn=three_region[0]
    minn=three_region[0]

    for point in three_region:
        if point[1]>maxn[1]:
            maxn=point
        if point[1]<minn[1]:
            minn=point
    zhong=(maxn[1]-minn[1])/10

    for point in three_region:
        if point[1]>=minn[1]+0*zhong and point[1]<=minn[1]+1*zhong:

            _region_three_1.append(point)
        if point[1]>minn[1]+1*zhong and point[1]<=minn[1]+2*zhong:
            _region_three_2.append(point)
        if point[1]>minn[1]+2*zhong and point[1]<=minn[1]+3*zhong:
            _region_three_3.append(point)
        if point[1]>minn[1]+3*zhong and point[1]<=minn[1]+4*zhong:
            _region_three_4.append(point)
        if point[1]>minn[1]+4*zhong and point[1]<=minn[1]+5*zhong:
            _region_three_5.append(point)
        if point[1]>minn[1]+5*zhong and point[1]<=minn[1]+6*zhong:
            _region_three_6.append(point)
        if point[1]>minn[1]+6*zhong and point[1]<=minn[1]+7*zhong:
            _region_three_7.append(point)
        if point[1]>minn[1]+7*zhong and point[1]<=minn[1]+8*zhong:
            _region_three_8.append(point)
        if point[1]>minn[1]+8*zhong and point[1]<=minn[1]+9*zhong:
            _region_three_9.append(point)
        if point[1]>minn[1]+9*zhong and point[1]<=minn[1]+10*zhong:
            _region_three_10.append(point)


    intensity_region_a_1.append(calculate_intensity(gray_img, _region_three_1))
    intensity_region_a_2.append(calculate_intensity(gray_img, _region_three_2))
    intensity_region_a_3.append(calculate_intensity(gray_img, _region_three_3))
    intensity_region_a_4.append(calculate_intensity(gray_img, _region_three_4))
    intensity_region_a_5.append(calculate_intensity(gray_img, _region_three_5))
    intensity_region_a_6.append(calculate_intensity(gray_img, _region_three_6))
    intensity_region_a_7.append(calculate_intensity(gray_img, _region_three_7))
    intensity_region_a_8.append(calculate_intensity(gray_img, _region_three_8))
    intensity_region_a_9.append(calculate_intensity(gray_img, _region_three_9))
    intensity_region_a_10.append(calculate_intensity(gray_img, _region_three_10))

    intensity_region_1_1.append(calculate_intensity(gray_img, region_1_1))
    intensity_region_1_2.append(calculate_intensity(gray_img, region_1_2))
    intensity_region_1_3.append(calculate_intensity(gray_img, region_1_3))
    intensity_region_1_4.append(calculate_intensity(gray_img, region_1_4))
    intensity_region_1_5.append(calculate_intensity(gray_img, region_1_5))
    intensity_region_1_6.append(calculate_intensity(gray_img, region_1_6))
    intensity_region_1_7.append(calculate_intensity(gray_img, region_1_7))
    intensity_region_1_8.append(calculate_intensity(gray_img, region_1_8))
    intensity_region_1_9.append(calculate_intensity(gray_img, region_1_9))
    intensity_region_1_10.append(calculate_intensity(gray_img, region_1_10))

    intensity_region_2_1.append(calculate_intensity(gray_img, region_2_1))
    intensity_region_2_2.append(calculate_intensity(gray_img, region_2_2))
    intensity_region_2_3.append(calculate_intensity(gray_img, region_2_3))
    intensity_region_2_4.append(calculate_intensity(gray_img, region_2_4))
    intensity_region_2_5.append(calculate_intensity(gray_img, region_2_5))
    intensity_region_2_6.append(calculate_intensity(gray_img, region_2_6))
    intensity_region_2_7.append(calculate_intensity(gray_img, region_2_7))
    intensity_region_2_8.append(calculate_intensity(gray_img, region_2_8))
    intensity_region_2_9.append(calculate_intensity(gray_img, region_2_9))
    intensity_region_2_10.append(calculate_intensity(gray_img, region_2_10))

    intensity_region_3_1.append(calculate_intensity(gray_img, region_3_1))
    intensity_region_3_2.append(calculate_intensity(gray_img, region_3_2))
    intensity_region_3_3.append(calculate_intensity(gray_img, region_3_3))
    intensity_region_3_4.append(calculate_intensity(gray_img, region_3_4))
    intensity_region_3_5.append(calculate_intensity(gray_img, region_3_5))
    intensity_region_3_6.append(calculate_intensity(gray_img, region_3_6))
    intensity_region_3_7.append(calculate_intensity(gray_img, region_3_7))
    intensity_region_3_8.append(calculate_intensity(gray_img, region_3_8))
    intensity_region_3_9.append(calculate_intensity(gray_img, region_3_9))
    intensity_region_3_10.append(calculate_intensity(gray_img, region_3_10))

    intensity__region_1_1.append(calculate_intensity(gray_img, _region_1_1))
    intensity__region_1_2.append(calculate_intensity(gray_img, _region_1_2))
    intensity__region_1_3.append(calculate_intensity(gray_img, _region_1_3))
    intensity__region_1_4.append(calculate_intensity(gray_img, _region_1_4))
    intensity__region_1_5.append(calculate_intensity(gray_img, _region_1_5))
    intensity__region_1_6.append(calculate_intensity(gray_img, _region_1_6))
    intensity__region_1_7.append(calculate_intensity(gray_img, _region_1_7))
    intensity__region_1_8.append(calculate_intensity(gray_img, _region_1_8))
    intensity__region_1_9.append(calculate_intensity(gray_img, _region_1_9))
    intensity__region_1_10.append(calculate_intensity(gray_img, _region_1_10))

    intensity__region_2_1.append(calculate_intensity(gray_img, _region_2_1))
    intensity__region_2_2.append(calculate_intensity(gray_img, _region_2_2))
    intensity__region_2_3.append(calculate_intensity(gray_img, _region_2_3))
    intensity__region_2_4.append(calculate_intensity(gray_img, _region_2_4))
    intensity__region_2_5.append(calculate_intensity(gray_img, _region_2_5))
    intensity__region_2_6.append(calculate_intensity(gray_img, _region_2_6))
    intensity__region_2_7.append(calculate_intensity(gray_img, _region_2_7))
    intensity__region_2_8.append(calculate_intensity(gray_img, _region_2_8))
    intensity__region_2_9.append(calculate_intensity(gray_img, _region_2_9))
    intensity__region_2_10.append(calculate_intensity(gray_img, _region_2_10))

    intensity__region_3_1.append(calculate_intensity(gray_img, _region_3_1))
    intensity__region_3_2.append(calculate_intensity(gray_img, _region_3_2))
    intensity__region_3_3.append(calculate_intensity(gray_img, _region_3_3))
    intensity__region_3_4.append(calculate_intensity(gray_img, _region_3_4))
    intensity__region_3_5.append(calculate_intensity(gray_img, _region_3_5))
    intensity__region_3_6.append(calculate_intensity(gray_img, _region_3_6))
    intensity__region_3_7.append(calculate_intensity(gray_img, _region_3_7))
    intensity__region_3_8.append(calculate_intensity(gray_img, _region_3_8))
    intensity__region_3_9.append(calculate_intensity(gray_img, _region_3_9))
    intensity__region_3_10.append(calculate_intensity(gray_img, _region_3_10))

    # intensity_regionn.append(calculate_intensity(gray_img,regionn))
    if i == 25:
        plt.figure(figsize=(10, 10))
        plt.imshow(gray_img, cmap='gray')

        # 可视化三个区域
        plt.scatter([p[1] for p in region_1_1], [p[0] for p in region_1_1], color='lavender', s=5, label='1_1')
        plt.scatter([p[1] for p in region_1_2], [p[0] for p in region_1_2], color='lightsteelblue', s=5)
        plt.scatter([p[1] for p in region_1_3], [p[0] for p in region_1_3], color='slategrey', s=5)
        plt.scatter([p[1] for p in region_1_4], [p[0] for p in region_1_4], color='cornflowerblue', s=5)
        plt.scatter([p[1] for p in region_1_5], [p[0] for p in region_1_5], color='royalblue', s=5)
        plt.scatter([p[1] for p in region_1_6], [p[0] for p in region_1_6], color='dodgerblue', s=5)
        plt.scatter([p[1] for p in region_1_7], [p[0] for p in region_1_7], color='steelblue', s=5)
        plt.scatter([p[1] for p in region_1_8], [p[0] for p in region_1_8], color='deepskyblue', s=5)
        plt.scatter([p[1] for p in region_1_9], [p[0] for p in region_1_9], color='b', s=5)
        plt.scatter([p[1] for p in region_1_10], [p[0] for p in region_1_10], color='darkblue', s=5, label='1_10')

        plt.scatter([p[1] for p in region_2_1], [p[0] for p in region_2_1], color='honeydew', s=5, label='2_1')
        plt.scatter([p[1] for p in region_2_2], [p[0] for p in region_2_2], color='palegreen', s=5)
        plt.scatter([p[1] for p in region_2_3], [p[0] for p in region_2_3], color='darkseagreen', s=5)
        plt.scatter([p[1] for p in region_2_4], [p[0] for p in region_2_4], color='olivedrab', s=5)
        plt.scatter([p[1] for p in region_2_5], [p[0] for p in region_2_5], color='springgreen', s=5)
        plt.scatter([p[1] for p in region_2_6], [p[0] for p in region_2_6], color='lime', s=5)
        plt.scatter([p[1] for p in region_2_7], [p[0] for p in region_2_7], color='limegreen', s=5)
        plt.scatter([p[1] for p in region_2_8], [p[0] for p in region_2_8], color='darkolivegreen', s=5)
        plt.scatter([p[1] for p in region_2_9], [p[0] for p in region_2_9], color='green', s=5)
        plt.scatter([p[1] for p in region_2_10], [p[0] for p in region_2_10], color='darkgreen', s=5, label='2_10')

        plt.scatter([p[1] for p in region_3_1], [p[0] for p in region_3_1], color='mistyrose', s=5, label='3_1')
        plt.scatter([p[1] for p in region_3_2], [p[0] for p in region_3_2], color='lightsalmon', s=5)
        plt.scatter([p[1] for p in region_3_3], [p[0] for p in region_3_3], color='salmon', s=5)
        plt.scatter([p[1] for p in region_3_4], [p[0] for p in region_3_4], color='tomato', s=5)
        plt.scatter([p[1] for p in region_3_5], [p[0] for p in region_3_5], color='orangered', s=5)
        plt.scatter([p[1] for p in region_3_6], [p[0] for p in region_3_6], color='lightcoral', s=5)
        plt.scatter([p[1] for p in region_3_7], [p[0] for p in region_3_7], color='red', s=5)
        plt.scatter([p[1] for p in region_3_8], [p[0] for p in region_3_8], color='indianred', s=5)
        plt.scatter([p[1] for p in region_3_9], [p[0] for p in region_3_9], color='firebrick', s=5)
        plt.scatter([p[1] for p in region_3_10], [p[0] for p in region_3_10], color='maroon', s=5, label='3_10')

        plt.scatter([p[1] for p in _region_1_1], [p[0] for p in _region_1_1], color='azure', s=5, label='4_1')
        plt.scatter([p[1] for p in _region_1_2], [p[0] for p in _region_1_2], color='lightcyan', s=5)
        plt.scatter([p[1] for p in _region_1_3], [p[0] for p in _region_1_3], color='paleturquoise', s=5)
        plt.scatter([p[1] for p in _region_1_4], [p[0] for p in _region_1_4], color='aquamarine', s=5)
        plt.scatter([p[1] for p in _region_1_5], [p[0] for p in _region_1_5], color='turquoise', s=5)
        plt.scatter([p[1] for p in _region_1_6], [p[0] for p in _region_1_6], color='lightseagreen', s=5)
        plt.scatter([p[1] for p in _region_1_7], [p[0] for p in _region_1_7], color='cyan', s=5)
        plt.scatter([p[1] for p in _region_1_8], [p[0] for p in _region_1_8], color='darkturquoise', s=5)
        plt.scatter([p[1] for p in _region_1_9], [p[0] for p in _region_1_9], color='darkcyan', s=5)
        plt.scatter([p[1] for p in _region_1_10], [p[0] for p in _region_1_10], color='darkslategrey', s=5, label='4_10')

        plt.scatter([p[1] for p in _region_2_1], [p[0] for p in _region_2_1], color='thistle', s=5, label='5_1')
        plt.scatter([p[1] for p in _region_2_2], [p[0] for p in _region_2_2], color='plum', s=5)
        plt.scatter([p[1] for p in _region_2_3], [p[0] for p in _region_2_3], color='violet', s=5)
        plt.scatter([p[1] for p in _region_2_4], [p[0] for p in _region_2_4], color='mediumorchid', s=5)
        plt.scatter([p[1] for p in _region_2_5], [p[0] for p in _region_2_5], color='m', s=5)
        plt.scatter([p[1] for p in _region_2_6], [p[0] for p in _region_2_6], color='fuchsia', s=5)
        plt.scatter([p[1] for p in _region_2_7], [p[0] for p in _region_2_7], color='darkorchid', s=5)
        plt.scatter([p[1] for p in _region_2_8], [p[0] for p in _region_2_8], color='purple', s=5)
        plt.scatter([p[1] for p in _region_2_9], [p[0] for p in _region_2_9], color='blueviolet', s=5)
        plt.scatter([p[1] for p in _region_2_10], [p[0] for p in _region_2_10], color='indigo', s=5, label='5_10')

        plt.scatter([p[1] for p in _region_3_1], [p[0] for p in _region_3_1], color='lightyellow', s=5, label='6_1')
        plt.scatter([p[1] for p in _region_3_2], [p[0] for p in _region_3_2], color='lemonchiffon', s=5)
        plt.scatter([p[1] for p in _region_3_3], [p[0] for p in _region_3_3], color='khaki', s=5)
        plt.scatter([p[1] for p in _region_3_4], [p[0] for p in _region_3_4], color='yellow', s=5)
        plt.scatter([p[1] for p in _region_3_5], [p[0] for p in _region_3_5], color='gold', s=5)
        plt.scatter([p[1] for p in _region_3_6], [p[0] for p in _region_3_6], color='y', s=5)
        plt.scatter([p[1] for p in _region_3_7], [p[0] for p in _region_3_7], color='goldenrod', s=5)
        plt.scatter([p[1] for p in _region_3_8], [p[0] for p in _region_3_8], color='darkkhaki', s=5)
        plt.scatter([p[1] for p in _region_3_9], [p[0] for p in _region_3_9], color='darkgoldenrod', s=5)
        plt.scatter([p[1] for p in _region_3_10], [p[0] for p in _region_3_10], color='olive', s=5, label='6_10')

        plt.scatter([p[1] for p in _region_three_1], [p[0] for p in _region_three_1], color='linen', s=5, label='apical_1')
        plt.scatter([p[1] for p in _region_three_2], [p[0] for p in _region_three_2], color='bisque', s=5)
        plt.scatter([p[1] for p in _region_three_3], [p[0] for p in _region_three_3], color='sandybrown', s=5)
        plt.scatter([p[1] for p in _region_three_4], [p[0] for p in _region_three_4], color='orange', s=5)
        plt.scatter([p[1] for p in _region_three_5], [p[0] for p in _region_three_5], color='darkorange', s=5)
        plt.scatter([p[1] for p in _region_three_6], [p[0] for p in _region_three_6], color='chocolate', s=5)
        plt.scatter([p[1] for p in _region_three_7], [p[0] for p in _region_three_7], color='peru', s=5)
        plt.scatter([p[1] for p in _region_three_8], [p[0] for p in _region_three_8], color='saddlebrown', s=5)
        plt.scatter([p[1] for p in _region_three_9], [p[0] for p in _region_three_9], color='sienna', s=5)
        plt.scatter([p[1] for p in _region_three_10], [p[0] for p in _region_three_10], color='maroon', s=5, label='apical_10')
        # plt.scatter([p[1] for p in regionn], [p[0] for p in regionn], color='black', s=5, label='_70')
        plt.legend()
        plt.title("Regions on Image")
        plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/verify/regions_10_10.png')
   
    i+=1

intensity_three_region=np.array(intensity_three_region)
intensity_region_a_1=np.array(intensity_region_a_1)
intensity_region_a_2=np.array(intensity_region_a_2)
intensity_region_a_3=np.array(intensity_region_a_3)
intensity_region_a_4=np.array(intensity_region_a_4)
intensity_region_a_5=np.array(intensity_region_a_5)
intensity_region_a_6=np.array(intensity_region_a_6)
intensity_region_a_7=np.array(intensity_region_a_7)
intensity_region_a_8=np.array(intensity_region_a_8)
intensity_region_a_9=np.array(intensity_region_a_9)
intensity_region_a_10=np.array(intensity_region_a_10)

intensity_region_1_1=np.array(intensity_region_1_1)
intensity_region_1_2=np.array(intensity_region_1_2)
intensity_region_1_3=np.array(intensity_region_1_3)
intensity_region_1_4=np.array(intensity_region_1_4)
intensity_region_1_5=np.array(intensity_region_1_5)
intensity_region_1_6=np.array(intensity_region_1_6)
intensity_region_1_7=np.array(intensity_region_1_7)
intensity_region_1_8=np.array(intensity_region_1_8)
intensity_region_1_9=np.array(intensity_region_1_9)
intensity_region_1_10=np.array(intensity_region_1_10)

intensity_region_2_1=np.array(intensity_region_2_1)
intensity_region_2_2=np.array(intensity_region_2_2)
intensity_region_2_3=np.array(intensity_region_2_3)
intensity_region_2_4=np.array(intensity_region_2_4)
intensity_region_2_5=np.array(intensity_region_2_5)
intensity_region_2_6=np.array(intensity_region_2_6)
intensity_region_2_7=np.array(intensity_region_2_7)
intensity_region_2_8=np.array(intensity_region_2_8)
intensity_region_2_9=np.array(intensity_region_2_9)
intensity_region_2_10=np.array(intensity_region_2_10)

intensity_region_3_1=np.array(intensity_region_3_1)
intensity_region_3_2=np.array(intensity_region_3_2)
intensity_region_3_3=np.array(intensity_region_3_3)
intensity_region_3_4=np.array(intensity_region_3_4)
intensity_region_3_5=np.array(intensity_region_3_5)
intensity_region_3_6=np.array(intensity_region_3_6)
intensity_region_3_7=np.array(intensity_region_3_7)
intensity_region_3_8=np.array(intensity_region_3_8)
intensity_region_3_9=np.array(intensity_region_3_9)
intensity_region_3_10=np.array(intensity_region_3_10)

intensity__region_1_1=np.array(intensity__region_1_1)
intensity__region_1_2=np.array(intensity__region_1_2)
intensity__region_1_3=np.array(intensity__region_1_3)
intensity__region_1_4=np.array(intensity__region_1_4)
intensity__region_1_5=np.array(intensity__region_1_5)
intensity__region_1_6=np.array(intensity__region_1_6)
intensity__region_1_7=np.array(intensity__region_1_7)
intensity__region_1_8=np.array(intensity__region_1_8)
intensity__region_1_9=np.array(intensity__region_1_9)
intensity__region_1_10=np.array(intensity__region_1_10)

intensity__region_2_1=np.array(intensity__region_2_1)
intensity__region_2_2=np.array(intensity__region_2_2)
intensity__region_2_3=np.array(intensity__region_2_3)
intensity__region_2_4=np.array(intensity__region_2_4)
intensity__region_2_5=np.array(intensity__region_2_5)
intensity__region_2_6=np.array(intensity__region_2_6)
intensity__region_2_7=np.array(intensity__region_2_7)
intensity__region_2_8=np.array(intensity__region_2_8)
intensity__region_2_9=np.array(intensity__region_2_9)
intensity__region_2_10=np.array(intensity__region_2_10)

intensity__region_3_1=np.array(intensity__region_3_1)
intensity__region_3_2=np.array(intensity__region_3_2)
intensity__region_3_3=np.array(intensity__region_3_3)
intensity__region_3_4=np.array(intensity__region_3_4)
intensity__region_3_5=np.array(intensity__region_3_5)
intensity__region_3_6=np.array(intensity__region_3_6)
intensity__region_3_7=np.array(intensity__region_3_7)
intensity__region_3_8=np.array(intensity__region_3_8)
intensity__region_3_9=np.array(intensity__region_3_9)
intensity__region_3_10=np.array(intensity__region_3_10)

# # intensity_regionn=np.array(intensity_regionn)
tac_list_db_a_1,first_a_1=main(clean(intensity_region_a_1),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_1.png')
tac_list_db_a_2,first_a_2=main(clean(intensity_region_a_2),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_2.png')
tac_list_db_a_3,first_a_3=main(clean(intensity_region_a_3),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_3.png')
tac_list_db_a_4,first_a_4=main(clean(intensity_region_a_4),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_4.png')
tac_list_db_a_5,first_a_5=main(clean(intensity_region_a_5),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_5.png')
tac_list_db_a_6,first_a_6=main(clean(intensity_region_a_6),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_6.png')
tac_list_db_a_7,first_a_7=main(clean(intensity_region_a_7),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_7.png')
tac_list_db_a_8,first_a_8=main(clean(intensity_region_a_8),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_8.png')
tac_list_db_a_9,first_a_9=main(clean(intensity_region_a_9),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_9.png')
tac_list_db_a_10,first_a_10=main(clean(intensity_region_a_10),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_10.png')

tac_list_db_1_1,first_1_1=main(clean(intensity_region_1_1),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_1.png')
tac_list_db_1_2,first_1_2=main(clean(intensity_region_1_2),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_2.png')
tac_list_db_1_3,first_1_3=main(clean(intensity_region_1_3),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_3.png')
tac_list_db_1_4,first_1_4=main(clean(intensity_region_1_4),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_4.png')
tac_list_db_1_5,first_1_5=main(clean(intensity_region_1_5),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_5.png')
tac_list_db_1_6,first_1_6=main(clean(intensity_region_1_6),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_6.png')
tac_list_db_1_7,first_1_7=main(clean(intensity_region_1_7),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_7.png')
tac_list_db_1_8,first_1_8=main(clean(intensity_region_1_8),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_8.png')
tac_list_db_1_9,first_1_9=main(clean(intensity_region_1_9),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_9.png')
tac_list_db_1_10,first_1_10=main(clean(intensity_region_1_10),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_10.png')

tac_list_db_2_1,first_2_1=main(clean(intensity_region_2_1),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_1.png')
tac_list_db_2_2,first_2_2=main(clean(intensity_region_2_2),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_2.png')
tac_list_db_2_3,first_2_3=main(clean(intensity_region_2_3),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_3.png')
tac_list_db_2_4,first_2_4=main(clean(intensity_region_2_4),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_4.png')
tac_list_db_2_5,first_2_5=main(clean(intensity_region_2_5),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_5.png')
tac_list_db_2_6,first_2_6=main(clean(intensity_region_2_6),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_6.png')
tac_list_db_2_7,first_2_7=main(clean(intensity_region_2_7),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_7.png')
tac_list_db_2_8,first_2_8=main(clean(intensity_region_2_8),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_8.png')
tac_list_db_2_9,first_2_9=main(clean(intensity_region_2_9),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_9.png')
tac_list_db_2_10,first_2_10=main(clean(intensity_region_2_10),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_10.png')

tac_list_db_3_1,first_3_1=main(clean(intensity_region_3_1),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_1.png')
tac_list_db_3_2,first_3_2=main(clean(intensity_region_3_2),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_2.png')
tac_list_db_3_3,first_3_3=main(clean(intensity_region_3_3),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_3.png')
tac_list_db_3_4,first_3_4=main(clean(intensity_region_3_4),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_4.png')
tac_list_db_3_5,first_3_5=main(clean(intensity_region_3_5),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_5.png')
tac_list_db_3_6,first_3_6=main(clean(intensity_region_3_6),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_6.png')
tac_list_db_3_7,first_3_7=main(clean(intensity_region_3_7),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_7.png')
tac_list_db_3_8,first_3_8=main(clean(intensity_region_3_8),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_8.png')
tac_list_db_3_9,first_3_9=main(clean(intensity_region_3_9),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_9.png')
tac_list_db_3_10,first_3_10=main(clean(intensity_region_3_10),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_10.png')

_tac_list_db_1_1,_first_1_1=main(clean(intensity__region_1_1),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__1.png')
_tac_list_db_1_2,_first_1_2=main(clean(intensity__region_1_2),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__2.png')
_tac_list_db_1_3,_first_1_3=main(clean(intensity__region_1_3),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__3.png')
_tac_list_db_1_4,_first_1_4=main(clean(intensity__region_1_4),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__4.png')
_tac_list_db_1_5,_first_1_5=main(clean(intensity__region_1_5),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__5.png')
_tac_list_db_1_6,_first_1_6=main(clean(intensity__region_1_6),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__6.png')
_tac_list_db_1_7,_first_1_7=main(clean(intensity__region_1_7),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__7.png')
_tac_list_db_1_8,_first_1_8=main(clean(intensity__region_1_8),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__8.png')
_tac_list_db_1_9,_first_1_9=main(clean(intensity__region_1_9),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__9.png')
_tac_list_db_1_10,_first_1_10=main(clean(intensity__region_1_10),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1__10.png')

_tac_list_db_2_1,_first_2_1=main(clean(intensity__region_2_1),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__1.png')
_tac_list_db_2_2,_first_2_2=main(clean(intensity__region_2_2),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__2.png')
_tac_list_db_2_3,_first_2_3=main(clean(intensity__region_2_3),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__3.png')
_tac_list_db_2_4,_first_2_4=main(clean(intensity__region_2_4),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__4.png')
_tac_list_db_2_5,_first_2_5=main(clean(intensity__region_2_5),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__5.png')
_tac_list_db_2_6,_first_2_6=main(clean(intensity__region_2_6),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__6.png')
_tac_list_db_2_7,_first_2_7=main(clean(intensity__region_2_7),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__7.png')
_tac_list_db_2_8,_first_2_8=main(clean(intensity__region_2_8),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__8.png')
_tac_list_db_2_9,_first_2_9=main(clean(intensity__region_2_9),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__9.png')
_tac_list_db_2_10,_first_2_10=main(clean(intensity__region_2_10),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2__10.png')

_tac_list_db_3_1,_first_3_1=main(clean(intensity__region_3_1),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__1.png')
_tac_list_db_3_2,_first_3_2=main(clean(intensity__region_3_2),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__2.png')
_tac_list_db_3_3,_first_3_3=main(clean(intensity__region_3_3),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__3.png')
_tac_list_db_3_4,_first_3_4=main(clean(intensity__region_3_4),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__4.png')
_tac_list_db_3_5,_first_3_5=main(clean(intensity__region_3_5),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__5.png')
_tac_list_db_3_6,_first_3_6=main(clean(intensity__region_3_6),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__6.png')
_tac_list_db_3_7,_first_3_7=main(clean(intensity__region_3_7),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__7.png')
_tac_list_db_3_8,_first_3_8=main(clean(intensity__region_3_8),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__8.png')
_tac_list_db_3_9,_first_3_9=main(clean(intensity__region_3_9),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__9.png')
_tac_list_db_3_10,_first_3_10=main(clean(intensity__region_3_10),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3__10.png')

# # # tac_list_db_n,first_n=main(clean(intensity_regionn),'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/filter/n.png')
# 定义指数函数
# def exponential_func(t, a, b, c):
#     return a * (1 - np.exp(-b * t)) + c
#拟合曲线必须经过第一点
def exponential_func(t, a, b,x0,y0):
    return a * ((1 - np.exp(-b * t))-(1 - np.exp(-b * x0)))+y0

def carve(tac_list_db_,first,tac_path,name):
    tac_list_db_=np.array(tac_list_db_)
    clean(tac_list_db_)
        # 生成时间轴（假设时间间隔为1）
    time_axis = np.arange(len(tac_list_db_))/fps
    t = np.linspace(0, time_axis[-1], 1000)
    x0=0.05
    
    y0=min(tac_list_db_)
    tac_list_db_ = np.array(tac_list_db_)
    
    # 初始猜测参数 [a, b, c]
    initial_guess = [3, 6]
    smoothed_data = np.convolve(tac_list_db_, np.ones(5)/5, mode='valid')    # 曲线拟合
    params, params_covariance = curve_fit(lambda t,a,b:exponential_func(t,a,b,x0,y0), time_axis, tac_list_db_, p0=initial_guess, maxfev=4000)
    # 拟合结果
    fitted_signal = exponential_func(time_axis, *params,x0,y0)

    # 打印拟合参数
    print(f"{name}参数: A = {params[0]}, β = {params[1]}")
    s=f"A = {params[0]}, β = {params[1]}"
    minn=min(tac_list_db_)
    tac_list_db_[0]=0
    # 绘制原始数据和拟合曲线
    plt.figure(figsize=(12,6))
    a = list(range(0,math.ceil(len(tac_list_db_)/fps),1))
    plt.xticks(a)
    plt.text(1, max(tac_list_db_)+0.5, s, fontsize=15, color="green")
    plt.plot(time_axis, tac_list_db_, label='line')
    plt.plot(time_axis, fitted_signal,  color='red')
    plt.xlim(0,int(len(tac_list_db_)/fps))
    plt.ylim(minn - 1, max(tac_list_db_) + 1)
    plt.xlabel('t / s')
    plt.ylabel('mean_intensity / dB')
    plt.legend()
    plt.savefig(tac_path)
    plt.show()

    return params[0]*params[1]

_2_a=[]
_2_rd=[]
_2_rm=[]
_2_ru=[]
_2_ld=[]
_2_lm=[]
_2_lu=[]
_2_a_1=carve(tac_list_db_a_1,first_a_1,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_1.png','apical left 1')
_2_a_2=carve(tac_list_db_a_2,first_a_2,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_2.png','2')
_2_a_3=carve(tac_list_db_a_3,first_a_3,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_3.png','3')
_2_a_4=carve(tac_list_db_a_4,first_a_4,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_4.png','4')
_2_a_5=carve(tac_list_db_a_5,first_a_5,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_5.png','5')
_2_a_6=carve(tac_list_db_a_6,first_a_6,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_6.png','6')
_2_a_7=carve(tac_list_db_a_7,first_a_7,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_7.png','7')
_2_a_8=carve(tac_list_db_a_8,first_a_8,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_8.png','8')
_2_a_9=carve(tac_list_db_a_9,first_a_9,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_9.png','9')
_2_a_10=carve(tac_list_db_a_10,first_a_10,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/a_10.png','apical right 10')
_2_a.extend((_2_a_1,_2_a_2,_2_a_3,_2_a_4,_2_a_5,_2_a_6,_2_a_7,_2_a_8,_2_a_9,_2_a_10))
_1=carve(tac_list_db_1_1,first_1_1,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_1.png','right down 1')
_2=carve(tac_list_db_1_2,first_1_2,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_2.png','2')
_3=carve(tac_list_db_1_3,first_1_3,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_3.png','3')
_4=carve(tac_list_db_1_4,first_1_4,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_4.png','4')
_5=carve(tac_list_db_1_5,first_1_5,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_5.png','5')
_6=carve(tac_list_db_1_6,first_1_6,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_6.png','6')
_7=carve(tac_list_db_1_7,first_1_7,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_7.png','7')
_8=carve(tac_list_db_1_8,first_1_8,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_8.png','8')
_9=carve(tac_list_db_1_9,first_1_9,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_9.png','9')
_10=carve(tac_list_db_1_10,first_1_10,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/1_10.png',10)
_2_rd.extend((_1,_2,_3,_4,_5,_6,_7,_8,_9,_10))
_1=carve(tac_list_db_2_1,first_2_1,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_1.png','right mid 1')
_2=carve(tac_list_db_2_2,first_2_2,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_2.png','2')
_3=carve(tac_list_db_2_3,first_2_3,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_3.png','3')
_4=carve(tac_list_db_2_4,first_2_4,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_4.png','4')
_5=carve(tac_list_db_2_5,first_2_5,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_5.png','5')
_6=carve(tac_list_db_2_6,first_2_6,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_6.png','6')
_7=carve(tac_list_db_2_7,first_2_7,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_7.png','7')
_8=carve(tac_list_db_2_8,first_2_8,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_8.png','8')
_9=carve(tac_list_db_2_9,first_2_9,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_9.png','9')
_10=carve(tac_list_db_2_10,first_2_10,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/2_10.png','right mid 10')
_2_rm.extend((_1,_2,_3,_4,_5,_6,_7,_8,_9,_10))
_1=carve(tac_list_db_3_1,first_3_1,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_1.png','right up 1')
_2=carve(tac_list_db_3_2,first_3_2,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_2.png','2')
_3=carve(tac_list_db_3_3,first_3_3,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_3.png','3')
_4=carve(tac_list_db_3_4,first_3_4,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_4.png','4')
_5=carve(tac_list_db_3_5,first_3_5,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_5.png','5')
_6=carve(tac_list_db_3_6,first_3_6,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_6.png','6')
_7=carve(tac_list_db_3_7,first_3_7,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_7.png','7')
_8=carve(tac_list_db_3_8,first_3_8,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_8.png','8')
_9=carve(tac_list_db_3_9,first_3_9,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_9.png','9')
_10=carve(tac_list_db_3_10,first_3_10,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/3_10.png','right up 10')
_2_ru.extend((_1,_2,_3,_4,_5,_6,_7,_8,_9,_10))
_1=carve(_tac_list_db_1_1,_first_1_1,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_1.png','left down 1')
_2=carve(_tac_list_db_1_2,_first_1_2,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_2.png','2')
_3=carve(_tac_list_db_1_3,_first_1_3,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_3.png','3')
_4=carve(_tac_list_db_1_4,_first_1_4,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_4.png','4')
_5=carve(_tac_list_db_1_5,_first_1_5,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_5.png','5')
_6=carve(_tac_list_db_1_6,_first_1_6,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_6.png','6')
_7=carve(_tac_list_db_1_7,_first_1_7,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_7.png','7')
_8=carve(_tac_list_db_1_8,_first_1_8,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_8.png','8')
_9=carve(_tac_list_db_1_9,_first_1_9,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_9.png','9')
_10=carve(_tac_list_db_1_10,_first_1_10,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_1_10.png','left down 10')
_2_ld.extend((_1,_2,_3,_4,_5,_6,_7,_8,_9,_10))
_1=carve(_tac_list_db_2_1,_first_2_1,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_1.png','left mid 1')
_2=carve(_tac_list_db_2_2,_first_2_2,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_2.png','2')
_3=carve(_tac_list_db_2_3,_first_2_3,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_3.png','3')
_4=carve(_tac_list_db_2_4,_first_2_4,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_4.png','4')
_5=carve(_tac_list_db_2_5,_first_2_5,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_5.png','5')
_6=carve(_tac_list_db_2_6,_first_2_6,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_6.png','6')
_7=carve(_tac_list_db_2_7,_first_2_7,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_7.png','7')
_8=carve(_tac_list_db_2_8,_first_2_8,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_8.png','8')
_9=carve(_tac_list_db_2_9,_first_2_9,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_9.png','9')
_10=carve(_tac_list_db_2_10,_first_2_10,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_2_10.png','left mid 10')
_2_lm.extend((_1,_2,_3,_4,_5,_6,_7,_8,_9,_10))
_1=carve(_tac_list_db_3_1,_first_3_1,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_1.png','left up 1')
_2=carve(_tac_list_db_3_2,_first_3_2,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_2.png','2')
_3=carve(_tac_list_db_3_3,_first_3_3,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_3.png','3')
_4=carve(_tac_list_db_3_4,_first_3_4,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_4.png','4')
_5=carve(_tac_list_db_3_5,_first_3_5,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_5.png','5')
_6=carve(_tac_list_db_3_6,_first_3_6,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_6.png','6')
_7=carve(_tac_list_db_3_7,_first_3_7,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_7.png','7')
_8=carve(_tac_list_db_3_8,_first_3_8,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_8.png','8')
_9=carve(_tac_list_db_3_9,_first_3_9,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_9.png','9')
_10=carve(_tac_list_db_3_10,_first_3_10,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/_10_10/_3_10.png','left up 10')
_2_lu.extend((_1,_2,_3,_4,_5,_6,_7,_8,_9,_10))
print(_2_lu)
# # carve(tac_list_db_n,first_n,'/data/stu1/liuanqi/heart_2C/heart_myunet/segmentation/carve/n.png')
