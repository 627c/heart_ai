import torch
from torch import nn
from torch.nn import functional as F    #插值法
import torchvision.models as models
from torchvision.models.segmentation.deeplabv3 import DeepLabHead

class DeepLabV3(nn.Module):
    def __init__(self, n_classes):
        super(DeepLabV3, self).__init__()
        self.base_model = models.segmentation.deeplabv3_resnet50(pretrained=True)
        self.base_model.classifier = DeepLabHead(2048, n_classes)

    def forward(self, x):
        return self.base_model(x)['out']    

if __name__=='__main__':
    x=torch.randn(2,3,256,256)
    net=DeepLabV3(n_classes=3)
    print(net(x).shape)