import os
import torch
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, jaccard_score, precision_score, recall_score, f1_score
import seaborn as sns

from net import *
from utils import *
from train import *
from data import *

def binarize(tensor, threshold=0.5):
    return (tensor > threshold).float()

net=AttentionUNet().cuda()
weights='/data/stu1/liuanqi/heart_2C/models/Attention U-Net/params/unet.pth'
if os.path.exists(weights):
    net.load_state_dict(torch.load(weights))
    print('successful')
else:
    print('no loading')

def load_test_data(image_dir, label_dir):
    """
    加载测试数据和标签。
    
    参数:
    - image_dir: 存储测试图像的目录路径
    - label_dir: 存储标签图像的目录路径
    - img_size: 图像大小，默认是 (256, 256)
    
    返回:
    - test_images: 测试图像的Numpy数组
    - test_labels: 标签图像的Numpy数组
    """
    test_images = []
    test_labels = []

    for img_file in os.listdir(image_dir):
        # 构建完整路径
        img_path = os.path.join(image_dir, img_file)
        lbl_file=img_file.replace('.jpg','.png')
        lbl_path = os.path.join(label_dir, lbl_file)

        # 检查文件是否存在
        if not os.path.exists(img_path) or not os.path.exists(lbl_path):
            print(f"Warning: {img_path} or {lbl_path} does not exist. Skipping.")
            continue

        # 读取图像和标签
        img = keep_image_size_open(img_path)
        img_data=transform(img).cuda()
        print(img_data.shape)
        img_data=torch.unsqueeze(img_data,dim=0)
        label = keep_image_size_open(lbl_path)
        label_data=transform(label).cuda()
        label_data=torch.unsqueeze(label_data,dim=0)          # 转换为张量并添加batch维度

        # 将图像和标签添加到列表
        # img_data = torch.tensor(img_data).float().cuda()
        # label_data = torch.tensor(label_data).long().cuda()
        test_images.append(img_data)
        test_labels.append(label_data)

    return test_images, test_labels

image_dir='/data/stu1/liuanqi/heart_2C/heart_myunet/test_data/JPEGImages'
label_dir='/data/stu1/liuanqi/heart_2C/heart_myunet/test_data/SegmentationClass'
test_images, test_labels = load_test_data(image_dir,label_dir)
# test_images= torch.tensor([item.cpu().detach().numpy() for item in test_images]).cuda()
# test_labels= torch.tensor([item.cpu().detach().numpy() for item in test_labels]).cuda()

# 预测
# net.eval()  # 设置为评估模式
# with torch.no_grad():
#     predictions = net(test_images)

# # 转换预测结果为numpy数组并进行二值化
# predictions_np = predictions.cpu().numpy()
# test_labels_np = test_labels.cpu().numpy()
# predictions_binary = (predictions_np > 0.5).astype(int)
#预测
def convert_to_numpy(tensor_list):
    # 将嵌套的 PyTorch 张量列表转换为简单的 Numpy 数组列表
    numpy_list = []
    for tensor in tensor_list:
        if isinstance(tensor, torch.Tensor):
            numpy_list.append(tensor.cpu().numpy())
        elif isinstance(tensor, list):
            numpy_list.extend(convert_to_numpy(tensor))  # 递归处理嵌套列表
        else:
            raise TypeError("Element is not a Torch Tensor or list")
    return numpy_list
#预测
predictions=[]
predictions_binary=[]
for test_image in test_images:
    net.eval()  # 设置为评估模式
    with torch.no_grad():
        prediction = net(test_image)
    # print(prediction)
    prediction_binary=(prediction > 0.5).float()
    predictions.append(prediction)
    predictions_binary.append(prediction_binary)

test_labels_np=[]
for test_label in test_labels:
    test_label=(test_label > 0.5).float()
    test_labels_np.append(test_label)
# print(test_labels_np)
    
# 转换预测结果为numpy数组并进行二值化
predictions_np = convert_to_numpy(predictions)
test_labels_np = convert_to_numpy(test_labels_np)
# print(test_labels_np)

predictions_binary = convert_to_numpy(predictions_binary)
# print(predictions_binary)
test_images=convert_to_numpy(test_images)
# print(test_images)

### 3. 计算评价指标
def _iou(predicted, target):
    # 确保输入的predicted和target是二值化后的浮点数张量，然后转换为整数（0或1）
    predicted_int = predicted.int()
    target_int = target.int()

    intersection = (predicted_int & target_int).sum((1, 2))  # 求交集
    union = (predicted_int | target_int).sum((1, 2))         # 求并集

    iou = (intersection + 1e-6) / (union + 1e-6)             # 防止除以0
    return iou.mean()                                        # 返回批次的平均IoU


def calculate_metrics(y_true, y_pred,iou_pre,iou_label):
    y_true_flat = y_true.flatten()
    y_pred_flat = y_pred.flatten()
    
    cm = confusion_matrix(y_true_flat, y_pred_flat)
    if len(cm.ravel()) == 4:
        TN, FP, FN, TP = cm.ravel()
    else:
        TN, FP, FN, TP = 0, 0, 0, 0
    output_binary = binarize(iou_pre, threshold=0.5)      # 模型输出二值化
    label_binary = binarize(iou_label, threshold=0.5) # 标签二值化
    iou = _iou(output_binary, label_binary)
    iou=iou.item()
    # print(iou)
    dice = f1_score(y_true_flat, y_pred_flat, average='binary')
    # print(dice)
    precision = precision_score(y_true_flat, y_pred_flat, average='binary')
    recall = recall_score(y_true_flat, y_pred_flat, average='binary')
    accuracy = (TP + TN) / (TP + TN + FP + FN) if (TP + TN + FP + FN) != 0 else 0
    
    return {
        'iou': iou,
        'dice': dice,
        'precision': precision,
        'recall': recall,
        'accuracy': accuracy
    }

metrics_list = [calculate_metrics(test_labels_np[i], predictions_binary[i],predictions[i],test_labels[i]) for i in range(len(test_labels_np))]
print(metrics_list)
average_metrics = {key: np.mean([m[key] for m in metrics_list]) for key in metrics_list[0].keys()}
print("Average Metrics:", average_metrics)

### 4. 可视化

# 假设 test_images 是 PyTorch 张量并且形状为 [N, C, H, W]
def show_predictions(test_images, test_labels, predictions_binary):
    num_examples = 5
    plt.figure(figsize=(15, num_examples * 5))
    for i in range(num_examples):
        plt.subplot(num_examples, 3, i * 3 + 1)
        img = test_images[i].squeeze().transpose(1, 2, 0)  # 将形状从 (C, H, W) 转换为 (H, W, C)
        plt.imshow(img, cmap='gray')
        plt.title("Input Image")

        plt.subplot(num_examples, 3, i * 3 + 2)
        gt = test_labels[i].squeeze()  # 如果是多通道，将其转换为单通道灰度图
        if len(gt.shape) == 3:
            gt = gt[0]  # 使用第一个通道
        plt.imshow(gt, cmap='gray')
        plt.title("Ground Truth")

        plt.subplot(num_examples, 3, i * 3 + 3)
        pred = predictions_binary[i].squeeze()
        if len(pred.shape) == 3:
            pred = pred[0]  # 使用第一个通道
        plt.imshow(pred, cmap='gray')
        plt.title("Prediction")

    plt.tight_layout()
    plt.show()
    plt.savefig('/data/stu1/liuanqi/heart_2C/models/Attention U-Net/performance/prediction.png')

# 调用函数显示结果
show_predictions(test_images, test_labels_np, predictions_binary)

#### 绘制评价指标柱状图

metric_names = list(average_metrics.keys())
metric_values = list(average_metrics.values())

plt.figure(figsize=(10, 6))
barlist = plt.bar(metric_names, metric_values, color='skyblue')
for i, value in enumerate(metric_values):
    plt.text(i, value + 0.01, f'{value:.4f}', ha='center',va='bottom')
plt.xlabel('Metrics')
plt.ylabel('Values')
plt.ylim(0, 1)
plt.title('Performance Metrics')
plt.show()
plt.savefig('/data/stu1/liuanqi/heart_2C/models/Attention U-Net/performance/metrics.png')

#### 自定义混淆矩阵可视化

def plot_confusion_matrix(y_true, y_pred, title='Confusion Matrix'):
    cm = confusion_matrix(y_true.flatten(), y_pred.flatten())
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.title(title)
    plt.show()
    plt.savefig('/data/stu1/liuanqi/heart_2C/models/Attention U-Net/performance/confusion_matrix.png')

# 转换为 numpy 数组，并进行 flatten 操作
test_labels_np_flat = np.concatenate([label.flatten() for label in test_labels_np])
predictions_binary_flat = np.concatenate([pred.flatten() for pred in predictions_binary])

# 绘制混淆矩阵
plot_confusion_matrix(test_labels_np_flat, predictions_binary_flat)