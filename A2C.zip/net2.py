import torch
from torch import nn
from torch.nn import functional as F    #插值法
from torchvision.models import resnet18

#self参数：指的是实例本身，不能省略
#__init__()方法：必须包含一个self参数，而且要是第一个
#super(Net,self).__init__():首先找到Net的父类，然后把类Net的对象self转化为父类的对象

class Conv_Block(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(Conv_Block, self).__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(in_channel, out_channel, 3, 1, 1, padding_mode='reflect', bias=False),
            nn.BatchNorm2d(out_channel),
            nn.Dropout2d(0.3),
            nn.LeakyReLU(),
            nn.Conv2d(out_channel, out_channel, 3, 1, 1, padding_mode='reflect', bias=False),
            nn.BatchNorm2d(out_channel),
            nn.Dropout2d(0.3),
            nn.LeakyReLU()
        )

    def forward(self, x):
        return self.layer(x)

class ResConv_Block(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(ResConv_Block, self).__init__()
        self.conv1 = nn.Conv2d(in_channel, out_channel, 3, 1, 1, padding_mode='reflect', bias=False)
        self.bn1 = nn.BatchNorm2d(out_channel)
        self.relu = nn.LeakyReLU()
        self.conv2 = nn.Conv2d(out_channel, out_channel, 3, 1, 1, padding_mode='reflect', bias=False)
        self.bn2 = nn.BatchNorm2d(out_channel)
        self.dropout = nn.Dropout2d(0.3)
        self.skip = nn.Conv2d(in_channel, out_channel, 1, 1, 0, bias=False)

    def forward(self, x):
        identity = self.skip(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.dropout(out)
        out += identity
        out = self.relu(out)
        return out

class AttentionBlock(nn.Module):
    def __init__(self, in_channels):
        super(AttentionBlock, self).__init__()
        self.conv = nn.Conv2d(in_channels, in_channels // 2, 1)
        self.attention = nn.Conv2d(in_channels // 2, in_channels, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        attention_map = self.conv(x)
        attention_map = self.attention(attention_map)
        attention_map = self.sigmoid(attention_map)
        return x * attention_map

class TransformerBlock(nn.Module):
    def __init__(self, in_channels, d_model=256, nhead=8):
        super(TransformerBlock, self).__init__()
        self.linear_in = nn.Linear(in_channels, d_model)
        self.transformer = nn.Transformer(d_model, nhead=nhead, num_encoder_layers=1, batch_first=True)
        self.linear_out = nn.Linear(d_model, in_channels)

    def forward(self, x):
        b, c, h, w = x.shape
        # print(f"Input shape: {x.shape}")

        # Flatten the spatial dimensions and permute to (batch_size, seq_len, features)
        x = x.flatten(2).permute(0, 2, 1)  # -> (b, hw, c)
        # print(f"Shape after flatten and permute: {x.shape}")
        
        assert x.shape[2] == c, f"Expected last dimension to be {c}, but got {x.shape[2]}"
        
        # Linear transformation to match the d_model
        try:
            x = self.linear_in(x)  # -> (b, hw, d_model)
        except Exception as e:
            print(f"Error in linear_in: {e}")
            raise
        
        # print(f"Shape after linear_in: {x.shape}")

        assert x.shape[2] == self.linear_in.out_features, f"Expected last dimension to be {self.linear_in.out_features}, but got {x.shape[2]}"

        # Pass through transformer
        x = self.transformer(x, x)  # -> (b, hw, d_model)
        # print(f"Shape after transformer: {x.shape}")
        
        assert x.shape[2] == self.linear_in.out_features, f"Expected last dimension to be {self.linear_in.out_features}, but got {x.shape[2]}"

        # Linear transformation back to original feature dimension
        x = self.linear_out(x)  # -> (b, hw, c)
        # print(f"Shape after linear_out: {x.shape}")

        assert x.shape[2] == c, f"Expected last dimension to be {c}, but got {x.shape[2]}"

        # Reshape back to (b, c, h, w)
        x = x.permute(0, 2, 1).view(b, c, h, w)  # -> (b, c, h, w)
        # print(f"Output shape: {x.shape}")

        return x

class UNet(nn.Module):
    def __init__(self):
        super(UNet, self).__init__()
        self.c1 = Conv_Block(3, 64)
        self.d1 = DownSample(64)
        self.c2 = ResConv_Block(64, 128)
        self.d2 = DownSample(128)
        self.c3 = ResConv_Block(128, 256)
        self.d3 = DownSample(256)
        self.c4 = ResConv_Block(256, 512)
        self.d4 = DownSample(512)
        self.c5 = Conv_Block(512, 1024)
        self.d5 = DownSample(1024)
        self.u1 = UpSample(1024, 512)
        self.c6 = ResConv_Block(1024, 512)
        self.u2 = UpSample(512, 256)
        self.c7 = ResConv_Block(512, 256)
        self.u3 = UpSample(256, 128)
        self.c8 = ResConv_Block(256, 128)
        self.u4 = UpSample(128, 64)
        self.c9 = Conv_Block(128, 64)
        self.out = nn.Conv2d(64, 3, 3, 1, 1)
        self.TH = nn.Sigmoid()
        self.att1 = AttentionBlock(128)
        self.att2 = AttentionBlock(256)
        self.att3 = AttentionBlock(512)
        self.trans1 = TransformerBlock(128, d_model=256)
        self.trans2 = TransformerBlock(1024, d_model=256)

    def forward(self, x):
        R1 = self.c1(x)
        R2 = self.c2(self.d1(R1))
        R3 = self.c3(self.d2(R2))
        R4 = self.c4(self.d3(R3))
        R5 = self.c5(self.d4(R4))
        R5 = self.d5(R5)
        R5 = self.trans2(R5)

        # print(f"Shape before u1: R5: {R5.shape}, R4: {R4.shape}")
        O1 = self.c6(self.u1(R5, R4))
        # print(f"Shape before u2: O1: {O1.shape}, R3: {R3.shape}")
        O2 = self.c7(self.u2(O1, R3))
        # print(f"Shape before u3: O2: {O2.shape}, R2: {R2.shape}")
        O3 = self.c8(self.u3(O2, R2))
        # print(f"Shape before trans1: O3: {O3.shape}")
        O3 = self.trans1(O3)
        # print(f"Shape before u4: O3: {O3.shape}, R1: {R1.shape}")
        O4 = self.c9(self.u4(O3, R1))

        return self.TH(self.out(O4))

class DownSample(nn.Module):
    def __init__(self, channel):
        super(DownSample, self).__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(channel, channel, 3, 2, 1, padding_mode='reflect', bias=False),
            nn.BatchNorm2d(channel),
            nn.LeakyReLU()
        )

    def forward(self, x):
        return self.layer(x)

class UpSample(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(UpSample, self).__init__()
        self.layer = nn.Conv2d(in_channel, out_channel, 1, 1)

    def forward(self, x, feature_map):
        up = F.interpolate(x, size=feature_map.shape[2:], mode='nearest')
        out = self.layer(up)
        return torch.cat((out, feature_map), dim=1)
    
if __name__ == '__main__':
    net = UNet()
    if torch.cuda.device_count()>1:
        # print(f"使用{torch.cuda.device_count()}个gpus")
        net=nn.DataParallel(net)
    device=torch.device("cuda")
    net.to(device)
    x = torch.randn(2, 3, 256, 256).to(device)
    print(net(x).shape)