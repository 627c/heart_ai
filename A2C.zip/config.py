from detect_blank import *

video_path='/data/stu1/liuanqi/heart_2C/heart_myunet/video /病例五.avi'
video_to_picture='/data/stu1/liuanqi/heart_2C/heart_myunet/video_make_picture/1'
to_picture_mask='/data/stu1/liuanqi/heart_2C/heart_myunet/video_make_picture/1_out'
to_picture_mask_cover='/data/stu1/liuanqi/heart_2C/heart_myunet/video_make_picture/1_out_end'

after_flash_image='/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/image'
after_flash_binary='/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/binary'
after_flash_cover='/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_cover'

blank_frames = detect_blank_frames(video_path)
print(f"空白帧的位置: {blank_frames}")
flash=blank_frames[-1]
#获取帧率
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print("Error opening video stream or file")
fps = cap.get(cv2.CAP_PROP_FPS)  # 获取视频的FPS（帧率）
print(fps)
