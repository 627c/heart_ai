import cv2
import os
import math
import numpy as np
import matplotlib.pyplot as plt
from torchvision.utils import save_image
from scipy.optimize import curve_fit
from scipy.optimize import least_squares
from PIL import Image
from utils import *
from config import flash,fps,after_flash_binary,after_flash_cover

def main(cover,mask,flash):
    tac_list=[]
    for i in os.listdir(cover):
        segmented_region=cv2.imread(os.path.join(cover, i))
        binary=cv2.imread(os.path.join(mask, i))
        mean_intensity = np.mean(segmented_region[binary>0])
        tac_list.append(mean_intensity)
    tac_list=tac_list[flash+1:]
    #傅里叶变换
    # 1. 
    tac_list=np.array(tac_list)
    tac_list=tac_list-np.mean(tac_list)
    # 应用Hamming窗  
    # window = np.hamming(len(tac_list))  
    # signal_windowed = tac_list * window 
    freq_domain_signal = np.fft.fft(tac_list)
    freq_domain_signal=np.abs(freq_domain_signal)
    freq_domain_signal[0]=0
    # freq = np.fft.fftfreq(len(tac_list)/2*fps/len(tac_list))
    freq1 = np.fft.fftfreq(len(tac_list),1/fps)
    # freq=np.abs(freq)
    print(len(tac_list))
    # 计算幅值（取绝对值）
    magnitude = np.abs(freq_domain_signal)
    freq=np.fft.fftshift(freq1)
    magnitude=np.fft.fftshift(magnitude)
    print(f'Frequency shape: {freq.shape}')  
    print(f'Power Spectrum shape: {magnitude.shape}')      # 绘制频率域图像 (包括正频率与负频率)
    plt.figure(figsize=(18, 9))
    # 寻找峰值（使用np.argmax寻找最大值索引）  
    peaks = np.array([1, 0])  # 找到两个峰值的索引  
    peak_indices = np.argsort(magnitude)[-4:]  # 排序找到最大两个峰值索引
    peak_indices=peak_indices.tolist()
    print(peak_indices)
    peak_indices2 = np.argsort(magnitude)[-10:-8]  # 排序找到最大两个峰值索引
    print(peak_indices2)
    peak_indices.append(peak_indices2[0])
    peak_indices.append(peak_indices2[1])
    print(peak_indices)
    peak_freqs = freq[peak_indices]  # 对应的频率  
    peak_values = magnitude[peak_indices]  # 对应的幅度  
    print(f'peak_Frequency shape: {peak_freqs.shape}')  
    print(f'peak_Power Spectrum shape: {peak_values.shape}')      # 绘制频率域图像 (包括正频率与负频率)
    # plt.subplot(2, 1,1)
    # magnitude=magnitude-np.mean(magnitude)
    plt.plot(freq, magnitude, label="Magnitude Spectrum", color='blue')
    plt.scatter(peak_freqs, peak_values, color='red', label='Peaks')  

    # 标注峰值频率  
    i=0
    for (freq, amp) in zip(peak_freqs, peak_values):  
        if(freq<0):continue
        plt.annotate(f'{freq:.2f} Hz', xy=(freq, amp), xytext=(freq, amp + 10),   
                 fontsize=20)  
        i+=1

    plt.title("Frequency Domain: Magnitude Spectrum",fontsize=24)
    plt.tick_params(axis='both', labelsize=22)
    plt.xlabel("Frequency (Hz)",fontsize=22)
    plt.ylabel("Amplitude",fontsize=22)
    # 添加主网格  
    plt.grid(which='major', linestyle='-', linewidth='0.5', color='gray')  

    # # 添加次网格  
    # plt.minorticks_on()  # 开启次刻度  
    # plt.grid(which='minor', linestyle=':', linewidth='0.5', color='lightgray')
    # # plt.legend(fontsize=16)

    # # 绘制功率谱密度 (PSD)
    # power_spectrum = magnitude**2
    # plt.subplot(2, 1, 2)
    # # power_spectrum=power_spectrum-np.mean(power_spectrum)
    # plt.plot(freq, power_spectrum, label="Power Spectral Density", color='green')
    # plt.tick_params(axis='both', labelsize=22)
    # plt.title("Power Spectral Density (PSD)",fontsize=24)
    # plt.xlabel("Frequency (Hz)",fontsize=22)
    # plt.ylabel("Power",fontsize=22)
    # # 添加主网格  
    # plt.grid(which='major', linestyle='-', linewidth='0.5', color='gray')  

    # # 添加次网格  
    # plt.minorticks_on()  # 开启次刻度  
    # plt.grid(which='minor', linestyle=':', linewidth='0.5', color='lightgray')
    # # plt.legend(fontsize=20)

    plt.tight_layout()
    plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/_pinpu1.png')
    plt.show()
    # """
    # 计算累积能量，并展示保留一定百分比的频率成分时，信号保留的能量。
    
    # Args:
    # - freq_domain_signal: 频率域信号
    # - percentage_kept: 保留的频率成分百分比 (默认保留前10%)
    
    # Returns:
    # - threshold: 保留下来的频率成分的阈值索引
    # """
    # power_spectrum = np.abs(freq_domain_signal)**2  # 计算功率谱
    # percentage_kept=0.6
    # total_power = np.sum(power_spectrum)  # 总能量
    # cumulative_power = np.cumsum(power_spectrum)  # 累积能量

    # # 计算在不同频率下保留的累积能量百分比
    # cumulative_percentage = cumulative_power / total_power

    # # 找到累积达到一定百分比的阈值位置（如前10%）
    # threshold_index = np.where(cumulative_percentage >= percentage_kept)[0][0]

    # print(f"To retain {percentage_kept*100:.2f}% of the signal's energy, keep first {threshold_index} frequency components.")
    
    # # 绘制累积能量曲线
    # plt.figure(figsize=(12, 6))
    # plt.plot(np.arange(len(cumulative_percentage)), cumulative_percentage * 100, label='Cumulative Energy')
    # plt.axhline(y=percentage_kept * 100, color='r', linestyle='--', label=f'{percentage_kept*100:.2f}% Energy Threshold')
    # plt.axvline(x=threshold_index, color='g', linestyle='--', label=f'Cutoff at {threshold_index}')
    # plt.tick_params(axis='both', labelsize=22)
    # plt.title('Cumulative Energy Distribution Across Frequencies',fontsize=24)
    # plt.xlabel('Frequency Component Index',fontsize=22)
    # plt.ylabel('Cumulative Percentage of Total Energy (%)',fontsize=19)
    # plt.legend(fontsize=22)
    # # 添加主网格  
    # plt.grid(which='major', linestyle='-', linewidth='0.5', color='gray')  

    # # 添加次网格  
    # plt.minorticks_on()  # 开启次刻度  
    # plt.grid(which='minor', linestyle=':', linewidth='0.5', color='lightgray')
    # plt.legend(fontsize=22)
    # plt.tight_layout()
    # plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/_leiji.png')
    # plt.show()

    # 2. 设定频率阈值，过滤高频噪声
    # threshold = threshold_index
    threshold = int(len(freq_domain_signal) * 0.25)
    print(threshold)
    filtered_freq_domain_signal = np.zeros_like(freq_domain_signal)
    filtered_freq_domain_signal[:threshold] = freq_domain_signal[:threshold]
    filtered_freq_domain_signal[-threshold:] = freq_domain_signal[-threshold:]

    # 3. 逆傅里叶变换，得到过滤后的时间域信号
    filtered_signal = np.fft.ifft(filtered_freq_domain_signal).real

    # # 绘制原始信号与过滤后的信号
    # plt.figure(figsize=(12, 8))

    # plt.subplot(2, 1, 1)
    # plt.plot(tac_list, label="Original Signal")
    # # plt.legend(fontsize=22)
    # # 添加主网格  
    # plt.grid(which='major', linestyle='-', linewidth='0.5', color='gray')  

    # # 添加次网格  
    # plt.minorticks_on()  # 开启次刻度  
    # plt.grid(which='minor', linestyle=':', linewidth='0.5', color='lightgray')
    # plt.xlim(0,228)
    # plt.tick_params(axis='both', labelsize=20)
    # plt.title("Original Signal",fontsize=26)
    # plt.subplot(2, 1, 2)
    # plt.plot(filtered_signal, label="Filtered Signal", color='red')
    # # plt.legend(fontsize=20)
    # # 添加主网格  
    # plt.grid(which='major', linestyle='-', linewidth='0.5', color='gray')  

    # # 添加次网格  
    # plt.minorticks_on()  # 开启次刻度  
    # plt.grid(which='minor', linestyle=':', linewidth='0.5', color='lightgray')
    # plt.xlim(0,228)
    # plt.tick_params(axis='both', labelsize=20)
    # plt.title("Filtered Signal",fontsize=26)
    # plt.subplots_adjust(hspace=0.3)
    # plt.tight_layout()
    # plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/_filtered.png') 
    #  # 频谱图  
    # plt.figure(figsize=(12, 6))
    # freq_domain_signal=freq_domain_signal-np.mean(freq_domain_signal)
    # plt.plot(freq, np.abs(freq_domain_signal), label="Frequency Spectrum")  
    # plt.legend(fontsize=22)  
    # plt.tick_params(axis='both', labelsize=22) 
    # plt.title("Frequency Spectrum",fontsize=24)  
    # plt.grid(which='both', linestyle='-', linewidth='0.5', color='gray')  
    # plt.minorticks_on()  
    # plt.grid(which='minor', linestyle=':', linewidth='0.5', color='lightgray')  
    # plt.xlim(0, 0.5)  # 频率范围可以根据需要调整  
    # plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/_pinpu.png')
    # plt.tight_layout()
    # plt.show()
    tac_list=filtered_signal
    print(tac_list)
    first_intensity=tac_list[0]
    first_intensity_db=np.abs(10*np.log10(first_intensity))
    tac_list_=np.array(tac_list)
    mean_intensity=np.mean(tac_list_)
    mean_intensity_db=np.abs(10*np.log10(mean_intensity))
    tac_list_db=(10*np.log10(np.maximum(tac_list_,1e-7)/first_intensity))+first_intensity_db
    tac_list_db=tac_list_db.tolist()
    return tac_list,tac_list_db,mean_intensity_db

tac_list_,tac_list_db_,first_=main(after_flash_cover,after_flash_binary,flash)
# tac_list_left,tac_list_db_left,first_left=main(lmask_path,lsave_path1)
# print(tac_list_left)

# print("tac:",tac_list_)
# print("tac_db:",tac_list_db_)
# print(first_)
# # 定义指数函数
# def exponential_func(t, a, b,x0,y0):
#     return a * ((1 - np.exp(-b * t))-(1 - np.exp(-b * x0)))+y0

# # 生成时间轴（假设时间间隔为1）
# time_axis = np.arange(len(tac_list_db_))/fps
# t = np.linspace(0, time_axis[-1], 1000)

# tac_list_db_ = np.array(tac_list_db_)

# # 初始猜测参数 [a, b, c]
# initial_guess = [1, 2]
# x0=0.05
# y0=min(tac_list_db_)

# # 曲线拟合
# params, params_covariance = curve_fit(lambda t,a,b:exponential_func(t,a,b,x0,y0), time_axis, tac_list_db_, p0=initial_guess)

# # 拟合结果
# fitted_signal = exponential_func(time_axis, *params,x0,y0)

# # 打印拟合参数
# print(f"参数: A = {params[0]}, β = {params[1]}")
# s=f"A = {params[0]}, β = {params[1]}"
# minn=min(tac_list_db_)
# tac_list_db_[0]=0
# # 绘制原始数据和拟合曲线
# plt.figure(figsize=(12,6))
# a = list(range(0,math.ceil(len(tac_list_db_)/fps),1))
# plt.xticks(a)
# plt.text(1, max(tac_list_db_)+0.5, s, fontsize=15, color="green")
# plt.plot(time_axis, tac_list_db_, label='line')
# plt.plot(time_axis, fitted_signal,  color='red')
# plt.xlim(0,int(len(tac_list_db_)/fps))
# plt.ylim(minn - 1, max(tac_list_db_) + 1)
# plt.xlabel('t / s')
# plt.ylabel('mean_intensity / dB')
# plt.legend()
# plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/tac_carve/tac.png')
# plt.show()
# time_axis = np.arange(len(tac_list_db_))/fps
# y = f(t)+first_-A
# # 绘制TAC图像
# plt.figure()
# plt.plot(time_axis, tac_list_db_,label='line')
# plt.plot(t, y)
# plt.title('Function Plot')
# plt.xlabel('t')
# plt.ylabel('y')
# plt.grid(True)
# plt.show()

