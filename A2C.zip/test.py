import os
import torch
import cv2
import numpy as np

from net2 import *
from utils import *
from train import *
from data import *

from torchvision.utils import save_image
from PIL import Image
from torchvision.transforms.functional import to_tensor
from torchvision.transforms.functional import to_pil_image

def binarize(tensor, threshold=0.5):
    return (tensor > threshold).float()

# IOU计算函数
def iou(predicted, target):
    # 确保输入的predicted和target是二值化后的浮点数张量，然后转换为整数（0或1）
    predicted_int = predicted.int()
    target_int = target.int()

    intersection = (predicted_int & target_int).sum((1, 2))  # 求交集
    union = (predicted_int | target_int).sum((1, 2))         # 求并集

    iou = (intersection + 1e-6) / (union + 1e-6)             # 防止除以0
    return iou.mean()                                        # 返回批次的平均IoU

net=UNet().cuda()
weights='/data/stu1/liuanqi/heart_2C/heart_myunet/params/unet.pth'
if os.path.exists(weights):
    net.load_state_dict(torch.load(weights))
    print('successful')
else:
    print('no loading')

total_iou = 0.0
num_images = 0
i=0
alpha=0.2
test_image_path='/data/stu1/liuanqi/heart_2C/heart_myunet/test_data/JPEGImages'
label_path = '/data/stu1/liuanqi/heart_2C/heart_myunet/test_data/SegmentationClass'   # 假设标签和输入图像同名
save_path='/data/stu1/liuanqi/heart_2C/heart_myunet/result'
save_path_end='/data/stu1/liuanqi/heart_2C/heart_myunet/result_end'
for test_image in os.listdir(test_image_path):
    # 加载图像
    label_image=test_image.replace('.jpg','.png')
    img = keep_image_size_open(os.path.join(test_image_path, test_image))
    img_data=transform(img).cuda()
    print(img_data.shape)
    img_data=torch.unsqueeze(img_data,dim=0)
    if not os.path.exists(label_path):
        print(f'Label file not found: {label_path}')
    else:
        label = keep_image_size_open(os.path.join(label_path, label_image))
        label_data=transform(label).cuda()
        label_data=torch.unsqueeze(label_data,dim=0)          # 转换为张量并添加batch维度

    net.eval()
    with torch.no_grad():
        out=net(img_data)
        print(out)
    save_image(out,f'{save_path}/{i}.png')
    output_binary = binarize(out, threshold=0.5)      # 模型输出二值化
    label_binary = binarize(label_data, threshold=0.5) # 标签二值化
    iou_score = iou(output_binary, label_binary)
    total_iou += iou_score
    num_images += 1
    img_end=img.convert('RGBA')
    out = out.squeeze(0)
    out_pil=to_pil_image(out)
    out_end=out_pil.convert('RGBA')

    image_end=Image.blend(img_end,out_end,0.4)
    image_end.save(f'{save_path_end}/{i}.png')
    i+=1
"""     # 确保张量是3维的
    if img_data.dim() == 4:
        img_data = img_data.squeeze(0)
    if out.dim() == 4:
        out = out.squeeze(0)
    # 将张量转换为PIL图像
    image_pil = to_pil_image(img_data)
    image_cv = cv2.cvtColor(np.array(image_pil), cv2.COLOR_RGB2BGR)
     
    # 二值化掩膜并转换为三通道
    mask = torch.sigmoid(out)  # 将输出转换为概率值
    mask = (mask > 0.5).float()  # 二值化
    mask_pil = to_pil_image(mask)
    mask_cv = cv2.cvtColor(np.array(mask_pil), cv2.COLOR_RGB2GRAY)
    mask_colored = cv2.applyColorMap(mask_cv, cv2.COLORMAP_JET)  # 上色

    # 将掩膜叠加到原图上
    overlay = cv2.addWeighted(image_cv, 1 - alpha, mask_colored, alpha, 0)
    overlayed_pil = Image.fromarray(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB))
    overlayed_pil.save(f'{save_path_end}/{i}.png')
 """
 # 计算平均 IOU
average_iou = total_iou / num_images
print("Average IOU: ", average_iou)
