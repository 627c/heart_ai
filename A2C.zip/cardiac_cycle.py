import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
import cv2
import os
import math
import numpy as np
import matplotlib.pyplot as plt
from torchvision.utils import save_image
from scipy.optimize import curve_fit
from scipy.optimize import least_squares
from PIL import Image
from utils import *
from config import flash,fps,after_flash_binary,after_flash_cover

def main(cover,mask,flash):
    tac_list=[]
    for i in os.listdir(cover):
        segmented_region=cv2.imread(os.path.join(cover, i))
        binary=cv2.imread(os.path.join(mask, i))
        mean_intensity = np.mean(segmented_region[binary>0])
        tac_list.append(mean_intensity)
    tac_list=tac_list[flash+1:]

def calculate_cardiac_cycle_and_heart_rate(signal, sampling_rate):
    """
    根据超声信号计算心动周期和心率。
    
    Args:
    - signal: 经过滤波后的时间域信号 (如超声心动图中的强度随时间的变化)
    - sampling_rate: 信号采样率 (Hz)，定义每秒钟的样本数量
    
    Returns:
    - heart_rate: 心率 (单位：beats per minute, BPM)
    - cardiac_cycles: 心动周期（单位：秒）
    - peak_indices: 检测到的心动峰值的索引
    """

    # 1. 使用峰值检测找到每次心跳的位置
    # 我们假设每个峰值代表一次心跳
    peak_indices, _ = find_peaks(signal, distance=sampling_rate * 0.5)  # 假设最小心率60 bpm -> 间距0.5s

    # 2. 计算相邻峰值之间的时间差，即心动周期
    if len(peak_indices) < 2:
        print("没有足够的峰值来计算心动周期，请检查信号质量！")
        return None, None, None

    peak_times = peak_indices / sampling_rate  # 将峰值索引转换为时间点

    # 计算连续心动周期的时间间隔
    cardiac_cycles = np.diff(peak_times)

    # 输出平均心动周期和心率（BPM）
    average_cardiac_cycle = np.mean(cardiac_cycles)
    heart_rate = 60 / average_cardiac_cycle  # 每分钟心跳次数

    return heart_rate, cardiac_cycles, peak_indices

def plot_signal_with_peaks(signal, peak_indices, sampling_rate):
    """
    绘制信号并标记心动周期的峰值。
    
    Args:
    - signal: 输入的时间域信号
    - peak_indices: 峰值的索引
    - sampling_rate: 信号采样率
    """
    time_axis = np.arange(len(signal)) / sampling_rate  # 生成对应的时间轴

    plt.figure(figsize=(12, 7))
    plt.plot(time_axis, signal, label='Filtered Signal')
    plt.plot(peak_indices / sampling_rate, signal[peak_indices], 'ro', label='Detected Peaks')  # 标注峰值
    plt.tick_params(axis='both', labelsize=16)  # 
    plt.title('Signal with Detected Peaks (Heartbeats)',fontsize=24)
    plt.xlabel('Time (seconds)',fontsize=18)
    plt.ylabel('Amplitude',fontsize=18)
    plt.xlim(0,9)
    plt.legend(fontsize=18)
    # 添加主网格  
    plt.grid(which='major', linestyle='-', linewidth='0.5', color='gray')  

    # 添加次网格  
    plt.minorticks_on()  # 开启次刻度  
    plt.grid(which='minor', linestyle=':', linewidth='0.5', color='lightgray')
    plt.tight_layout()
    plt.savefig('/data/stu1/liuanqi/heart_2C/heart_myunet/tac_data/xintiao/xintiao.png')
    plt.show()

def main(tac_list, sampling_rate=80):
    # 原始信号
    # 1. 对信号进行傅里叶变换并去噪（低频滤波）
    freq_domain_signal = np.fft.fft(tac_list)
    threshold = 42
    filtered_freq_domain_signal = np.zeros_like(freq_domain_signal)
    filtered_freq_domain_signal[:threshold] = freq_domain_signal[:threshold]
    filtered_freq_domain_signal[-threshold:] = freq_domain_signal[-threshold:]

    # 逆傅里叶变换，得到过滤后的时间域信号
    filtered_signal = np.fft.ifft(filtered_freq_domain_signal).real

    # 2. 计算心动周期和心率
    heart_rate, cardiac_cycles, peak_indices = calculate_cardiac_cycle_and_heart_rate(filtered_signal, sampling_rate)

    if heart_rate is not None:
        print(f"Estimated Heart Rate: {heart_rate:.2f} BPM")
        print(f"Average Cardiac Cycle Duration: {np.mean(cardiac_cycles):.2f} seconds")

        # 3. 绘制信号及其峰值
        plot_signal_with_peaks(filtered_signal, peak_indices, sampling_rate)

    return heart_rate, cardiac_cycles

# 示例用法
if __name__ == "__main__":
    # 假设 tac_list 是超声心动图信号
 # 原始信号
    cover=after_flash_cover
    mask=after_flash_binary
    tac_list=[]
    for i in os.listdir(cover):
        segmented_region=cv2.imread(os.path.join(cover, i))
        binary=cv2.imread(os.path.join(mask, i))
        mean_intensity = np.mean(segmented_region[binary>0])
        tac_list.append(mean_intensity)
    tac_list=tac_list[flash+1:]
    tac_list = np.array(tac_list)
    
    # 假设信号的采样率为100 Hz，可以根据您的实际情况调整
    sampling_rate = 24.946 
    
    # 运行主函数，计算心动周期和心率
    heart_rate, cardiac_cycles = main(tac_list, sampling_rate)